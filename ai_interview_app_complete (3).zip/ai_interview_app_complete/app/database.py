import sqlite3
import hashlib

DB_NAME = "users.db"


def init_db():
    conn = sqlite3.connect(DB_NAME)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def add_user(username: str, password: str) -> bool:
    try:
        conn = sqlite3.connect(DB_NAME)
        cur = conn.cursor()

        hashed_password = hash_password(password)

        cur.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            (username, hashed_password)
        )

        conn.commit()
        conn.close()
        return True   # ✅ User created successfully

    except sqlite3.IntegrityError:
        # ❌ Username already exists
        return False

    except Exception as e:
        print("Signup error:", e)
        return False


def verify_user(username: str, password: str) -> bool:
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()

    hashed_password = hash_password(password)

    cur.execute(
        "SELECT * FROM users WHERE username=? AND password=?",
        (username, hashed_password)
    )

    user = cur.fetchone()
    conn.close()

    return user is not None
