import streamlit as st
import tempfile
import os
import numpy as np

from audio_recorder_streamlit import audio_recorder

# -------------------------------------------------
# Whisper Speech Recognition (NO FFmpeg Required!)
# -------------------------------------------------
try:
    import whisper
    import soundfile as sf
    from io import BytesIO
    import wave
    WHISPER_AVAILABLE = True
    
    # Load Whisper model (base is a good balance of speed and accuracy)
    # Options: tiny, base, small, medium, large
    @st.cache_resource
    def load_whisper_model():
        return whisper.load_model("base")
    
except ImportError as e:
    WHISPER_AVAILABLE = False
    st.error(f"⚠️ Install required packages: pip install openai-whisper soundfile")

from database import init_db, add_user, verify_user
from model import get_questions
from utils import log_response, load_progress

# -------------------------------------------------
# PAGE CONFIG
# -------------------------------------------------
st.set_page_config(
    page_title="AI Interview Coach",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# -------------------------------------------------
# ENHANCED GLOBAL STYLES WITH ANIMATIONS
# -------------------------------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');

/* CSS Variables for consistent theming */
:root {
    --primary: #6366f1;
    --primary-dark: #4f46e5;
    --secondary: #ec4899;
    --accent: #8b5cf6;
    --success: #10b981;
    --warning: #f59e0b;
    --dark-bg: #0f0f23;
    --card-bg: #1a1a2e;
    --text-primary: #ffffff;
    --text-secondary: rgba(255,255,255,0.7);
    --shadow: rgba(0, 0, 0, 0.3);
}

* {
    font-family: 'Sora', sans-serif;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Remove default Streamlit padding */
.block-container {
    padding: 2rem 4rem !important;
    max-width: 100% !important;
}

[data-testid="stAppViewContainer"] {
    background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #0f0f23 100%);
    background-attachment: fixed;
}

/* Animated background effect */
.stApp::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: 
        radial-gradient(circle at 20% 50%, rgba(99, 102, 241, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 80% 80%, rgba(139, 92, 246, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 40% 20%, rgba(236, 72, 153, 0.08) 0%, transparent 50%);
    pointer-events: none;
    animation: backgroundPulse 15s ease-in-out infinite;
}

@keyframes backgroundPulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
}

/* Typography */
h1, h2, h3, h4, h5, h6 {
    color: var(--text-primary) !important;
    font-weight: 700 !important;
    letter-spacing: -0.02em;
}

h1 {
    font-size: 3rem !important;
    background: linear-gradient(135deg, #6366f1, #ec4899, #8b5cf6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    animation: gradientShift 5s ease infinite;
}

@keyframes gradientShift {
    0%, 100% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
}

/* Premium Cards */
.premium-card {
    background: rgba(26, 26, 46, 0.6);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 24px;
    padding: 2.5rem;
    box-shadow: 0 20px 60px var(--shadow);
    animation: fadeInUp 0.6s ease-out;
}

.premium-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 25px 70px rgba(99, 102, 241, 0.3);
    border-color: rgba(99, 102, 241, 0.3);
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Accent Cards */
.accent-card {
    background: linear-gradient(135deg, var(--primary), var(--accent));
    border-radius: 20px;
    padding: 2rem;
    color: white;
    position: relative;
    overflow: hidden;
}

.accent-card::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    animation: rotate 10s linear infinite;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

/* Enhanced Buttons */
.stButton > button {
    background: linear-gradient(135deg, var(--primary), var(--secondary)) !important;
    color: white !important;
    border-radius: 12px !important;
    padding: 0.75rem 2rem !important;
    font-weight: 600 !important;
    border: none !important;
    box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
    transition: all 0.3s ease !important;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    font-size: 0.9rem !important;
}

.stButton > button:hover {
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 6px 25px rgba(99, 102, 241, 0.6);
}

.stButton > button:active {
    transform: translateY(0);
}

/* Question Display */
.question-display {
    background: linear-gradient(135deg, var(--secondary), var(--accent));
    border-radius: 20px;
    padding: 3rem;
    color: white;
    box-shadow: 0 10px 40px rgba(236, 72, 153, 0.4);
    position: relative;
    overflow: hidden;
    animation: slideIn 0.5s ease-out;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-50px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.question-display h3 {
    font-size: 1.5rem !important;
    line-height: 1.6;
    margin: 0 !important;
}

.question-number {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: rgba(255, 255, 255, 0.2);
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.85rem;
}

/* Voice Section */
.voice-section {
    background: rgba(26, 26, 46, 0.4);
    border: 2px dashed rgba(99, 102, 241, 0.3);
    border-radius: 16px;
    padding: 2rem;
    text-align: center;
    transition: all 0.3s ease;
}

.voice-section:hover {
    border-color: rgba(99, 102, 241, 0.6);
    background: rgba(26, 26, 46, 0.6);
}

/* Text Input & Text Area */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea {
    background: rgba(26, 26, 46, 0.6) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    border-radius: 12px !important;
    color: white !important;
    padding: 1rem !important;
    font-size: 1rem !important;
}

.stTextInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus {
    border-color: var(--primary) !important;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2) !important;
}

/* Radio Buttons */
.stRadio > div {
    background: rgba(26, 26, 46, 0.4);
    padding: 1rem;
    border-radius: 12px;
}

.stRadio > div > label {
    color: var(--text-secondary) !important;
}

/* Sidebar Styling */
[data-testid="stSidebar"] {
    background: rgba(15, 15, 35, 0.95) !important;
    backdrop-filter: blur(20px);
    border-right: 1px solid rgba(255, 255, 255, 0.1);
}

[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] {
    color: white;
}

/* Progress Cards */
.progress-card {
    background: rgba(26, 26, 46, 0.5);
    border-radius: 16px;
    padding: 1.5rem;
    margin: 1rem 0;
    border-left: 4px solid var(--primary);
    animation: fadeIn 0.4s ease-out;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Role Selection Cards */
.role-card {
    background: rgba(26, 26, 46, 0.6);
    border: 2px solid rgba(99, 102, 241, 0.2);
    border-radius: 16px;
    padding: 2rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.role-card:hover {
    transform: translateY(-8px);
    border-color: var(--primary);
    box-shadow: 0 15px 40px rgba(99, 102, 241, 0.4);
}

/* Interview Round Buttons */
.round-button {
    background: rgba(26, 26, 46, 0.6);
    border: 2px solid rgba(99, 102, 241, 0.3);
    border-radius: 16px;
    padding: 2rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    height: 100%;
}

.round-button:hover {
    background: rgba(99, 102, 241, 0.2);
    border-color: var(--primary);
    transform: scale(1.05);
}

/* Success/Error Messages */
.stSuccess, .stError, .stWarning, .stInfo {
    border-radius: 12px !important;
    padding: 1rem 1.5rem !important;
    animation: slideInRight 0.4s ease-out;
}

@keyframes slideInRight {
    from {
        opacity: 0;
        transform: translateX(50px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

/* Data Frame Styling */
.stDataFrame {
    border-radius: 12px;
    overflow: hidden;
}

/* Select Box */
.stSelectbox > div > div {
    background: rgba(26, 26, 46, 0.6) !important;
    border-radius: 12px !important;
    border-color: rgba(255, 255, 255, 0.1) !important;
}

/* Login Container */
.login-container {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
    margin-top: -2rem;
}

.login-card {
    max-width: 480px;
    width: 100%;
    animation: scaleIn 0.5s ease-out;
}

@keyframes scaleIn {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

/* Icon Styling */
.icon-large {
    font-size: 4rem;
    animation: bounce 2s ease-in-out infinite;
}

@keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

/* Progress Bar */
.progress-bar {
    height: 8px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    overflow: hidden;
    margin: 1rem 0;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary), var(--secondary));
    border-radius: 10px;
    transition: width 0.5s ease;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin: 2rem 0;
}

.stat-card {
    background: rgba(26, 26, 46, 0.5);
    padding: 1.5rem;
    border-radius: 12px;
    text-align: center;
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.stat-value {
    font-size: 2.5rem;
    font-weight: 700;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.stat-label {
    color: var(--text-secondary);
    font-size: 0.9rem;
    margin-top: 0.5rem;
}

/* Responsive Design */
@media (max-width: 768px) {
    .block-container {
        padding: 1rem !important;
    }
    
    h1 {
        font-size: 2rem !important;
    }
    
    .premium-card {
        padding: 1.5rem;
    }
}
</style>
""", unsafe_allow_html=True)

# -------------------------------------------------
# INIT DB
# -------------------------------------------------
init_db()

# -------------------------------------------------
# SESSION STATE
# -------------------------------------------------
defaults = {
    "logged_in": False,
    "username": None,
    "selected_role": None,
    "interview_round": None,
    "interview_started": False,
    "current_question_index": 0,
    "voice_text": "",
    "total_questions": 0
}
for k, v in defaults.items():
    st.session_state.setdefault(k, v)

# -------------------------------------------------
# WHISPER SPEECH TO TEXT - NO FFmpeg REQUIRED!
# -------------------------------------------------
def process_audio_bytes(audio_bytes):
    """
    Convert audio bytes to numpy array for Whisper without FFmpeg
    """
    try:
        # Try to read with wave module first (for WAV files)
        with wave.open(BytesIO(audio_bytes), 'rb') as wav_file:
            # Get audio parameters
            sample_rate = wav_file.getframerate()
            n_frames = wav_file.getnframes()
            audio_data = wav_file.readframes(n_frames)
            
            # Convert to numpy array
            audio_np = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
            
            # Convert to mono if stereo
            if wav_file.getnchannels() == 2:
                audio_np = audio_np.reshape(-1, 2).mean(axis=1)
            
            # Resample to 16kHz if needed (Whisper expects 16kHz)
            if sample_rate != 16000:
                # Simple resampling
                duration = len(audio_np) / sample_rate
                target_length = int(duration * 16000)
                audio_np = np.interp(
                    np.linspace(0, len(audio_np), target_length),
                    np.arange(len(audio_np)),
                    audio_np
                )
            
            return audio_np
    except Exception as e:
        print(f"Wave processing error: {e}")
        
    try:
        # Try soundfile as backup
        audio_np, sample_rate = sf.read(BytesIO(audio_bytes))
        
        # Convert to mono if stereo
        if len(audio_np.shape) > 1:
            audio_np = audio_np.mean(axis=1)
        
        # Resample to 16kHz if needed
        if sample_rate != 16000:
            duration = len(audio_np) / sample_rate
            target_length = int(duration * 16000)
            audio_np = np.interp(
                np.linspace(0, len(audio_np), target_length),
                np.arange(len(audio_np)),
                audio_np
            )
        
        return audio_np
    except Exception as e:
        print(f"Soundfile processing error: {e}")
        return None

def transcribe_audio(audio_bytes):
    """
    Transcribe audio using OpenAI Whisper - NO FFmpeg required!
    """
    if not WHISPER_AVAILABLE:
        return "❌ Whisper not installed.\n\nRun: pip install openai-whisper soundfile\n\n💡 Tip: Type your answer instead!"

    try:
        # Process audio bytes to numpy array
        audio_np = process_audio_bytes(audio_bytes)
        
        if audio_np is None or len(audio_np) == 0:
            return "❌ Could not process audio. Please try recording again."
        
        # Load Whisper model
        model = load_whisper_model()
        
        # Transcribe with Whisper (directly from numpy array, no temp file needed!)
        result = model.transcribe(
            audio_np,
            language="en",
            fp16=False,  # Use FP32 for better compatibility
            verbose=False
        )
        
        text = result.get("text", "").strip()
        
        if text:
            return text
        else:
            return "❌ No speech detected. Please speak clearly and try again."
                
    except Exception as e:
        return f"""❌ Transcription error occurred.

**Details:** {str(e)}

💡 Please try again or type your answer."""

# =================================================
# 🔐 ENHANCED LOGIN PAGE
# =================================================
if not st.session_state.logged_in:
    
    # Hide Streamlit's default header and padding for login page
    st.markdown("""
    <style>
    [data-testid="stHeader"] {
        display: none;
    }
    .block-container {
        padding-top: 0 !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="login-container">', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown("""
        <div class="login-card">
            <div style="text-align:center;margin-bottom:2rem;">
                <div class="icon-large">🎯</div>
                <h1 style="margin:1rem 0;">AI Interview Coach</h1>
                <p style="color:rgba(255,255,255,0.7);font-size:1.1rem;margin-bottom:0;">
                    Master your interview skills with AI-powered practice
                </p>
            </div>
        """, unsafe_allow_html=True)
        
        st.markdown('<div class="premium-card">', unsafe_allow_html=True)
        
        tab1, tab2 = st.tabs(["🔑 Login", "📝 Sign Up"])
        
        with tab1:
            st.markdown("<br>", unsafe_allow_html=True)
            username = st.text_input("Username", key="login_user", placeholder="Enter your username")
            password = st.text_input("Password", type="password", key="login_pass", placeholder="Enter your password")
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            if st.button("🚀 Login", use_container_width=True, key="login_btn"):
                if username and password:
                    if verify_user(username, password):
                        st.session_state.logged_in = True
                        st.session_state.username = username
                        st.success("✅ Login successful!")
                        st.rerun()
                    else:
                        st.error("❌ Invalid credentials")
                else:
                    st.warning("⚠️ Please fill in all fields")
        
        with tab2:
            st.markdown("<br>", unsafe_allow_html=True)
            new_username = st.text_input("Username", key="signup_user", placeholder="Choose a username")
            new_password = st.text_input("Password", type="password", key="signup_pass", placeholder="Create a password")
            confirm_password = st.text_input("Confirm Password", type="password", key="confirm_pass", placeholder="Confirm your password")
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            if st.button("✨ Create Account", use_container_width=True, key="signup_btn"):
                if new_username and new_password and confirm_password:
                    if new_password != confirm_password:
                        st.error("❌ Passwords don't match")
                    elif len(new_password) < 6:
                        st.warning("⚠️ Password should be at least 6 characters")
                    else:
                        if add_user(new_username, new_password):
                            st.success("✅ Account created! Please login.")
                        else:
                            st.error("❌ Username already exists")
                else:
                    st.warning("⚠️ Please fill in all fields")
        
        st.markdown("</div>", unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)
    st.stop()

# =================================================
# 🎨 ENHANCED SIDEBAR
# =================================================
with st.sidebar:
    st.markdown(f"""
    <div style="text-align:center;padding:2rem 1rem;border-bottom:1px solid rgba(255,255,255,0.1);">
        <div style="font-size:3.5rem;margin-bottom:1rem;">👤</div>
        <div style="font-size:1.2rem;font-weight:600;color:white;margin-bottom:0.5rem;">
            {st.session_state.username}
        </div>
        <div style="font-size:0.85rem;color:rgba(255,255,255,0.5);">
            Ready to ace your interview!
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    menu_options = ["🎯 Select Role", "🎤 Mock Interview", "📊 Track Progress", "🚪 Logout"]
    menu = st.radio("Navigation", menu_options, label_visibility="collapsed")

# =================================================
# 🎯 MAIN HEADER
# =================================================
st.markdown("""
<div style="text-align:center;padding:2rem 0;">
    <h1>🎯 AI Interview Coach</h1>
    <p style="color:rgba(255,255,255,0.7);font-size:1.2rem;">
        Your personal AI-powered interview preparation platform
    </p>
</div>
""", unsafe_allow_html=True)

# -------------------------------------------------
# 🎯 SELECT ROLE
# -------------------------------------------------
if menu == "🎯 Select Role":
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown('<div class="premium-card">', unsafe_allow_html=True)
        
        st.markdown("""
        <div style="text-align:center;margin-bottom:2rem;">
            <h2>🎯 Choose Your Role</h2>
            <p style="color:rgba(255,255,255,0.7);">
                Select the role you're preparing for to get customized interview questions
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        roles = ["ML Engineer", "Web Developer", "Data Analyst"]
        role_icons = {"ML Engineer": "🤖", "Web Developer": "💻", "Data Analyst": "📊"}
        
        selected_role = st.selectbox(
            "Role",
            roles,
            index=roles.index(st.session_state.selected_role) if st.session_state.selected_role else 0,
            label_visibility="collapsed"
        )
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        if st.button("💾 Save Role", use_container_width=True):
            st.session_state.selected_role = selected_role
            st.success(f"✅ Role saved: {role_icons.get(selected_role, '🎯')} {selected_role}")
            st.balloons()
        
        if st.session_state.selected_role:
            st.markdown(f"""
            <div style="text-align:center;margin-top:2rem;padding:1.5rem;background:rgba(99,102,241,0.1);border-radius:12px;">
                <div style="font-size:3rem;margin-bottom:0.5rem;">
                    {role_icons.get(st.session_state.selected_role, '🎯')}
                </div>
                <div style="color:white;font-weight:600;">
                    Current Role: {st.session_state.selected_role}
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("</div>", unsafe_allow_html=True)

# -------------------------------------------------
# 🎤 MOCK INTERVIEW
# -------------------------------------------------
elif menu == "🎤 Mock Interview":
    
    if not st.session_state.selected_role:
        st.markdown('<div class="premium-card" style="text-align:center;padding:3rem;">', unsafe_allow_html=True)
        st.markdown("""
        <div style="font-size:4rem;margin-bottom:1rem;">⚠️</div>
        <h2>Please Select a Role First</h2>
        <p style="color:rgba(255,255,255,0.7);margin-top:1rem;">
            Go to "Select Role" from the sidebar to choose your interview role
        </p>
        """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)
        st.stop()
    
    if not st.session_state.interview_started:
        
        st.markdown(f"""
        <div class="accent-card" style="text-align:center;margin-bottom:2rem;">
            <h2>🎯 Ready to Practice: {st.session_state.selected_role}</h2>
            <p style="font-size:1.1rem;margin-top:1rem;opacity:0.9;">
                Choose an interview round to begin your practice session
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns(3)
        
        rounds = [
            {"name": "Aptitude", "icon": "🧮", "desc": "Logic & Problem Solving"},
            {"name": "Technical", "icon": "💡", "desc": "Role-Specific Skills"},
            {"name": "HR", "icon": "🤝", "desc": "Behavioral Questions"}
        ]
        
        for col, round_info in zip([col1, col2, col3], rounds):
            with col:
                st.markdown(f"""
                <div class="round-button">
                    <div style="font-size:3rem;margin-bottom:1rem;">{round_info['icon']}</div>
                    <h3 style="margin-bottom:0.5rem;">{round_info['name']}</h3>
                    <p style="color:rgba(255,255,255,0.7);font-size:0.9rem;">
                        {round_info['desc']}
                    </p>
                </div>
                """, unsafe_allow_html=True)
                
                if st.button(f"Start {round_info['name']}", key=f"start_{round_info['name']}", use_container_width=True):
                    st.session_state.interview_round = round_info['name']
                    st.session_state.interview_started = True
                    st.session_state.current_question_index = 0
                    st.rerun()
    
    else:
        # Interview in progress
        qs = get_questions(st.session_state.selected_role, st.session_state.interview_round)
        st.session_state.total_questions = len(qs)
        
        if st.session_state.current_question_index >= len(qs):
            st.markdown("""
            <div class="premium-card" style="text-align:center;padding:3rem;">
                <div style="font-size:5rem;margin-bottom:1rem;">🎉</div>
                <h1>Congratulations!</h1>
                <p style="font-size:1.2rem;color:rgba(255,255,255,0.8);margin-top:1rem;">
                    You've completed the interview round!
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("🏠 Back to Home", use_container_width=True):
                st.session_state.interview_started = False
                st.session_state.current_question_index = 0
                st.rerun()
            
            st.stop()
        
        # Progress bar
        progress = (st.session_state.current_question_index / len(qs)) * 100
        
        st.markdown(f"""
        <div class="premium-card">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
                <h3 style="margin:0;">Question {st.session_state.current_question_index + 1} of {len(qs)}</h3>
                <span style="color:rgba(255,255,255,0.7);">{st.session_state.interview_round} Round</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width:{progress}%;"></div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Question display
        q = qs[st.session_state.current_question_index]
        st.markdown(f"""
        <div class="question-display">
            <div class="question-number">Q{st.session_state.current_question_index + 1}</div>
            <h3>{q}</h3>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Voice recording section with Whisper (No FFmpeg!)
        col1, col2 = st.columns([2, 3])
        
        with col1:
            st.markdown("""
            <div class="voice-section">
                <h4 style="margin-bottom:1rem;">🎤 Voice Answer</h4>
                <p style="color:rgba(255,255,255,0.7);font-size:0.9rem;margin-bottom:0.5rem;">
                    Powered by OpenAI Whisper - High Accuracy!
                </p>
                <p style="color:rgba(255,255,255,0.5);font-size:0.8rem;">
                    💡 Just speak naturally - No FFmpeg required!
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            # Audio recorder with better settings
            audio = audio_recorder(
                text="",
                recording_color="#ec4899",
                neutral_color="#6366f1",
                icon_name="microphone",
                icon_size="3x",
                pause_threshold=2.0,
                sample_rate=16000
            )
            
            if audio:
                with st.spinner("🔄 Transcribing with Whisper AI... Please wait"):
                    transcribed_text = transcribe_audio(audio)
                    
                    # Check if it's an error message
                    if transcribed_text.startswith("❌"):
                        st.error(transcribed_text)
                        st.session_state.voice_text = ""
                    else:
                        st.session_state.voice_text = transcribed_text
                        st.success("✅ Transcription complete!")
                        st.info(f"📝 **Transcribed:** {transcribed_text}")
        
        with col2:
            st.markdown('<div class="premium-card">', unsafe_allow_html=True)
            st.markdown("### ✍️ Type Your Answer")
            st.markdown('<p style="color:rgba(255,255,255,0.6);font-size:0.85rem;margin-bottom:1rem;">Edit the transcribed text or type directly</p>', unsafe_allow_html=True)
            answer = st.text_area(
                "Answer",
                value=st.session_state.voice_text,
                height=200,
                placeholder="Speak your answer or type here...",
                label_visibility="collapsed",
                help="You can edit the transcribed text or type your answer directly"
            )
            st.markdown("</div>", unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Submit button
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col2:
            if st.button("✅ Submit Answer", use_container_width=True, type="primary"):
                if answer.strip():
                    log_response(
                        st.session_state.username,
                        st.session_state.selected_role,
                        q,
                        answer,
                        [],
                        st.session_state.interview_round,
                    )
                    st.session_state.voice_text = ""
                    st.session_state.current_question_index += 1
                    st.success("✅ Answer submitted!")
                    st.rerun()
                else:
                    st.warning("⚠️ Please provide an answer before submitting")

# -------------------------------------------------
# 📊 TRACK PROGRESS
# -------------------------------------------------
elif menu == "📊 Track Progress":
    
    st.markdown("""
    <div class="accent-card" style="text-align:center;margin-bottom:2rem;">
        <h2>📊 Your Interview Progress</h2>
        <p style="font-size:1.1rem;margin-top:1rem;opacity:0.9;">
            Track your practice sessions and improve over time
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    data = load_progress(st.session_state.username)
    
    if data is not None and len(data) > 0:
        
        # Stats cards
        total_sessions = len(data)
        roles_practiced = data['role'].nunique() if 'role' in data.columns else 0
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown(f"""
            <div class="stat-card">
                <div class="stat-value">{total_sessions}</div>
                <div class="stat-label">Total Questions</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div class="stat-card">
                <div class="stat-value">{roles_practiced}</div>
                <div class="stat-label">Roles Practiced</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            rounds_practiced = data['interview_round'].nunique() if 'interview_round' in data.columns else 0
            st.markdown(f"""
            <div class="stat-card">
                <div class="stat-value">{rounds_practiced}</div>
                <div class="stat-label">Interview Rounds</div>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("<br><br>", unsafe_allow_html=True)
        
        # Data table
        st.markdown('<div class="premium-card">', unsafe_allow_html=True)
        st.markdown("### 📋 Detailed History")
        st.dataframe(data, use_container_width=True, height=400)
        st.markdown("</div>", unsafe_allow_html=True)
        
    else:
        st.markdown("""
        <div class="premium-card" style="text-align:center;padding:3rem;">
            <div style="font-size:4rem;margin-bottom:1rem;">📊</div>
            <h2>No Progress Yet</h2>
            <p style="color:rgba(255,255,255,0.7);margin-top:1rem;font-size:1.1rem;">
                Start your first mock interview to track your progress!
            </p>
        </div>
        """, unsafe_allow_html=True)

# -------------------------------------------------
# 🚪 LOGOUT
# -------------------------------------------------
elif menu == "🚪 Logout":
    st.markdown("""
    <div class="premium-card" style="text-align:center;padding:3rem;">
        <div style="font-size:4rem;margin-bottom:1rem;">👋</div>
        <h2>Come back soon!</h2>
        <p style="color:rgba(255,255,255,0.7);margin-top:1rem;">
            Keep practicing to ace your interviews!
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        if st.button("🚪 Confirm Logout", use_container_width=True, type="primary"):
            st.session_state.clear()
            st.success("✅ Logged out successfully!")
            st.rerun()