import pandas as pd
import os
from datetime import datetime

def log_response(username, role, question, answer, feedback, round_type):
    # Ensure data directory exists
    os.makedirs("data", exist_ok=True)
    filename = "data/feedback_log.csv"
    
    # Create new entry
    new_entry = {
        "username": username,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "role": role,
        "round": round_type,
        "question": question,
        "answer": answer,
        "feedback": " | ".join(feedback) if isinstance(feedback, list) else str(feedback)
    }
    
    try:
        # Read existing data or create new DataFrame
        if os.path.exists(filename):
            df = pd.read_csv(filename)
        else:
            df = pd.DataFrame(columns=new_entry.keys())
        
        # Append new entry and save
        df = pd.concat([df, pd.DataFrame([new_entry])], ignore_index=True)
        df.to_csv(filename, index=False)
    except Exception as e:
        print(f"Error saving feedback: {str(e)}")
        raise

def load_progress(username):
    filename = "data/feedback_log.csv"
    try:
        if os.path.exists(filename):
            df = pd.read_csv(filename)
            return df[df['username'] == username]
        return pd.DataFrame()
    except Exception as e:
        print(f"Error loading progress: {str(e)}")
        return pd.DataFrame()