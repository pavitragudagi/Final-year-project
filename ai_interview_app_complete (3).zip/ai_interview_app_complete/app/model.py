def get_questions(role, round_type=None):
    questions_dict = {
        "ML Engineer": {
            "Aptitude": [
                "If a train travels 300 km in 3 hours, what is its average speed?",
                "What comes next in the sequence: 2, 4, 8, 16, ___?"
            ],
            "Technical": [
                "Explain the bias-variance tradeoff.",
                "How does gradient descent work?",
                "What's the difference between bagging and boosting?"
            ],
            "HR": [
                "Tell me about yourself.",
                "Why do you want to work as an ML Engineer?",
                "Describe a time you faced a difficult technical challenge."
            ]
        },
        "Web Developer": {
            "Aptitude": [
                "If you have 5 apples and give 2 away, how many do you have left?",
                "What is 25% of 200?"
            ],
            "Technical": [
                "What is the difference between HTML and XHTML?",
                "Explain the concept of RESTful APIs.",
                "How would you optimize website performance?"
            ],
            "HR": [
                "What motivates you as a developer?",
                "How do you handle disagreements with team members?",
                "Where do you see yourself in 5 years?"
            ]
        },
        "Data Analyst": {
            "Aptitude": [
                "If sales increased from $1,000 to $1,500, what's the percentage increase?",
                "What is the average of these numbers: 10, 20, 30, 40?"
            ],
            "Technical": [
                "What is the difference between inner and outer join in SQL?",
                "How do you handle missing data?",
                "Explain the difference between supervised and unsupervised learning."
            ],
            "HR": [
                "Why are you interested in data analysis?",
                "Describe a time when your analysis influenced a business decision.",
                "How do you ensure the accuracy of your reports?"
            ]
        }
    }
    
    if round_type:
        return questions_dict.get(role, {}).get(round_type, ["Tell me about yourself."])
    else:
        # Return all questions combined if no round specified (for backward compatibility)
        all_questions = []
        for round_questions in questions_dict.get(role, {}).values():
            all_questions.extend(round_questions)
        return all_questions if all_questions else ["Why are you interested in this role?"]

def evaluate_answer(answer):
    feedback = []
    answer = answer.strip().lower()
    
    # Length check
    word_count = len(answer.split())
    if word_count < 15:
        feedback.append(f"Try to elaborate more (currently {word_count} words). Aim for at least 30-50 words.")
    elif word_count > 100:
        feedback.append("Your answer is quite long. Consider being more concise while covering key points.")
    
    # Content checks
    if "i don't know" in answer:
        feedback.append("Avoid saying 'I don't know'. Try to structure a thoughtful guess.")
    if "example" not in answer and "for instance" not in answer:
        feedback.append("Consider giving a real-world example to back up your answer.")
    if "because" not in answer and "reason" not in answer:
        feedback.append("Try to explain your reasoning - interviewers want to understand your thought process.")
    
    if not feedback:
        feedback.append("Excellent response! You covered key points with good structure.")
    return feedback