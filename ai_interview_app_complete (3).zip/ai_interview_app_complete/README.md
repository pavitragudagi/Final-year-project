# AI-Powered Interview Preparation Site# AI-Powered Interview Preparation Site

# # Install Whisper and dependencies
# Step 1: --> python3.14 -m venv .venv 
#step 2: --> source .venv/bin/activate   
#step 3: -->  pip install openai-whisper streamlit audio-recorder-streamlit openai-whisper soundfile

# # step 4: --> Windows: Download from ffmpeg.org

# To Run
streamlit run app/main.py   

