#!/usr/bin/env python3
"""
Setup Verification Script
Verifies that all dependencies and configurations are properly set up
"""

import sys
import os
from pathlib import Path

def print_header(text):
    """Print formatted header"""
    print("\n" + "=" * 70)
    print(f"  {text}")
    print("=" * 70)

def print_status(check_name, status, message=""):
    """Print check status"""
    symbol = "✅" if status else "❌"
    print(f"{symbol} {check_name:<40} {message}")

def check_python_version():
    """Check Python version"""
    print_header("Python Version Check")
    version = sys.version_info
    required = (3, 9)
    
    current = f"{version.major}.{version.minor}.{version.micro}"
    required_str = f"{required[0]}.{required[1]}+"
    
    is_valid = version >= required
    print_status("Python Version", is_valid, f"Current: {current}, Required: {required_str}")
    return is_valid

def check_dependencies():
    """Check if all required packages are installed"""
    print_header("Dependency Check")
    
    required_packages = [
        'pandas', 'numpy', 'scikit-learn', 'scipy',
        'plotly', 'matplotlib', 'seaborn',
        'streamlit', 'textblob', 'nltk', 'spacy',
        'pyyaml', 'openpyxl', 'requests',
        'selenium', 'beautifulsoup4', 'lxml',
        'reportlab', 'python-docx', 'xlsxwriter',
        'python-dotenv', 'tqdm', 'joblib',
        'pytest'
    ]
    
    all_installed = True
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
            print_status(package, True, "Installed")
        except ImportError:
            print_status(package, False, "NOT INSTALLED")
            all_installed = False
    
    return all_installed

def check_nltk_data():
    """Check if NLTK data is downloaded"""
    print_header("NLTK Data Check")
    
    try:
        import nltk
        required_data = ['brown', 'punkt']
        all_present = True
        
        for data in required_data:
            try:
                nltk.data.find(f'corpora/{data}')
                print_status(f"NLTK {data}", True, "Downloaded")
            except LookupError:
                print_status(f"NLTK {data}", False, "NOT DOWNLOADED")
                all_present = False
        
        return all_present
    except ImportError:
        print_status("NLTK", False, "Package not installed")
        return False

def check_spacy_model():
    """Check if spaCy model is downloaded"""
    print_header("spaCy Model Check")
    
    try:
        import spacy
        try:
            nlp = spacy.load('en_core_web_sm')
            print_status("spaCy en_core_web_sm", True, "Model loaded")
            return True
        except OSError:
            print_status("spaCy en_core_web_sm", False, "Model NOT DOWNLOADED")
            return False
    except ImportError:
        print_status("spaCy", False, "Package not installed")
        return False

def check_directory_structure():
    """Check if required directories exist"""
    print_header("Directory Structure Check")
    
    required_dirs = [
        'config', 'modules', 'data', 'models', 'logs',
        'data/exports', 'docs', 'tests'
    ]
    
    all_exist = True
    for dir_path in required_dirs:
        path = Path(dir_path)
        exists = path.exists() and path.is_dir()
        print_status(dir_path, exists, "Exists" if exists else "MISSING")
        if not exists:
            all_exist = False
    
    return all_exist

def check_config_files():
    """Check if configuration files exist"""
    print_header("Configuration Files Check")
    
    required_files = [
        'config/config.yaml',
        'config/database.py',
        'config/logger.py',
        '.env.example',
        '.gitignore',
        'requirements.txt',
        'dashboard.py',
        'Dockerfile',
        'docker-compose.yml'
    ]
    
    all_exist = True
    for file_path in required_files:
        path = Path(file_path)
        exists = path.exists() and path.is_file()
        print_status(file_path, exists, "Exists" if exists else "MISSING")
        if not exists:
            all_exist = False
    
    return all_exist

def check_modules():
    """Check if all module files exist"""
    print_header("Module Files Check")
    
    required_modules = [
        'modules/module1_tracker.py',
        'modules/module2_virality.py',
        'modules/module3_sentiment.py',
        'modules/module4_ab_testing.py',
        'modules/module5_recommender.py',
        'modules/module7_trends.py',
        'modules/api_integrations.py',
        'modules/web_scraper.py',
        'modules/model_manager.py',
        'modules/export_manager.py'
    ]
    
    all_exist = True
    for module_path in required_modules:
        path = Path(module_path)
        exists = path.exists() and path.is_file()
        print_status(module_path, exists, "Exists" if exists else "MISSING")
        if not exists:
            all_exist = False
    
    return all_exist

def check_module_imports():
    """Check if modules can be imported"""
    print_header("Module Import Check")
    
    # Add modules directory to path
    sys.path.insert(0, str(Path(__file__).parent / "modules"))
    
    modules_to_test = [
        'module1_tracker',
        'module2_virality',
        'module3_sentiment',
        'module4_ab_testing',
        'module5_recommender',
        'module7_trends',
        'api_integrations',
        'web_scraper',
        'model_manager',
        'export_manager'
    ]
    
    all_importable = True
    for module_name in modules_to_test:
        try:
            __import__(module_name)
            print_status(module_name, True, "Importable")
        except Exception as e:
            print_status(module_name, False, f"Import Error: {str(e)[:30]}")
            all_importable = False
    
    return all_importable

def check_env_file():
    """Check if .env file exists (optional)"""
    print_header("Environment Configuration Check")
    
    env_exists = Path('.env').exists()
    print_status(".env file", env_exists, 
                "Configured" if env_exists else "Using defaults (OK for demo)")
    
    if not env_exists:
        print("\n  ℹ️  Note: .env file not found. Copy .env.example to .env for API integration.")
    
    return True  # Not critical for basic functionality

def check_database_init():
    """Check if database can be initialized"""
    print_header("Database Initialization Check")
    
    try:
        sys.path.insert(0, str(Path(__file__).parent / "config"))
        from database import DatabaseManager
        
        # Try to initialize database
        db = DatabaseManager()
        db.close()
        
        print_status("Database initialization", True, "Success")
        return True
    except Exception as e:
        print_status("Database initialization", False, f"Error: {str(e)[:40]}")
        return False

def provide_recommendations(results):
    """Provide recommendations based on check results"""
    print_header("Recommendations")
    
    if not results['python_version']:
        print("\n⚠️  Python version too old. Please upgrade to Python 3.9 or higher.")
        print("   Visit: https://www.python.org/downloads/")
    
    if not results['dependencies']:
        print("\n⚠️  Missing dependencies. Install with:")
        print("   pip install -r requirements.txt")
    
    if not results['nltk_data']:
        print("\n⚠️  NLTK data missing. Download with:")
        print("   python -m textblob.download_corpora")
    
    if not results['spacy_model']:
        print("\n⚠️  spaCy model missing. Download with:")
        print("   python -m spacy download en_core_web_sm")
    
    if not results['directory_structure']:
        print("\n⚠️  Some directories are missing. They will be created automatically.")
    
    if not results['config_files']:
        print("\n⚠️  Some configuration files are missing. Please check the project structure.")
    
    if not results['modules']:
        print("\n⚠️  Some module files are missing. Please ensure all files are present.")
    
    if not results['module_imports']:
        print("\n⚠️  Some modules cannot be imported. Check for syntax errors or missing dependencies.")
    
    if not results['database']:
        print("\n⚠️  Database initialization failed. Check config/config.yaml settings.")

def main():
    """Main verification function"""
    print("\n" + "=" * 70)
    print("  SOCIAL ENGAGEMENT INITIATIVE - SETUP VERIFICATION")
    print("=" * 70)
    print("\n  This script will verify your installation and configuration.")
    print("  Please wait while we run all checks...\n")
    
    # Run all checks
    results = {
        'python_version': check_python_version(),
        'dependencies': check_dependencies(),
        'nltk_data': check_nltk_data(),
        'spacy_model': check_spacy_model(),
        'directory_structure': check_directory_structure(),
        'config_files': check_config_files(),
        'modules': check_modules(),
        'module_imports': check_module_imports(),
        'env_file': check_env_file(),
        'database': check_database_init()
    }
    
    # Summary
    print_header("Summary")
    
    passed = sum(results.values())
    total = len(results)
    percentage = (passed / total) * 100
    
    print(f"\n  Checks Passed: {passed}/{total} ({percentage:.1f}%)")
    
    if passed == total:
        print("\n  🎉 All checks passed! Your setup is complete.")
        print("  You can now run the dashboard with: streamlit run dashboard.py")
    elif passed >= total * 0.7:
        print("\n  ⚠️  Most checks passed. Review recommendations below.")
        provide_recommendations(results)
    else:
        print("\n  ❌ Several checks failed. Please review recommendations below.")
        provide_recommendations(results)
    
    print("\n" + "=" * 70)
    print("  For detailed setup instructions, see: docs/USER_GUIDE.md")
    print("=" * 70 + "\n")
    
    return passed == total

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n⚠️  Verification interrupted by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        sys.exit(1)

