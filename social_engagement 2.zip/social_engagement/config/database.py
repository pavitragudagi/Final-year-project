"""
Database Manager - SQLite Integration
Handles all database operations for the Social Engagement Initiative
"""

import sqlite3
import pandas as pd
from pathlib import Path
from typing import Optional, List, Dict, Any
import yaml
from datetime import datetime


class DatabaseManager:
    """Manages SQLite database operations"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Initialize database connection"""
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        self.db_path = config['database']['path']
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = None
        self._init_database()
    
    def _init_database(self):
        """Create database tables if they don't exist"""
        self.conn = sqlite3.connect(self.db_path)
        cursor = self.conn.cursor()
        
        # Content Performance Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS content_performance (
                post_id TEXT PRIMARY KEY,
                platform TEXT NOT NULL,
                topic TEXT NOT NULL,
                format TEXT NOT NULL,
                hook_type TEXT NOT NULL,
                posting_time TEXT NOT NULL,
                date DATE NOT NULL,
                reach INTEGER,
                impressions INTEGER,
                likes INTEGER,
                comments INTEGER,
                shares INTEGER,
                saves INTEGER,
                retention_rate REAL,
                followers_gained INTEGER,
                viral_coefficient REAL,
                viral_tier TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Sentiment Analysis Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sentiment_analysis (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                post_id TEXT,
                comment TEXT NOT NULL,
                label TEXT NOT NULL,
                trigger_score REAL,
                polarity REAL,
                compound_score REAL,
                analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (post_id) REFERENCES content_performance(post_id)
            )
        """)
        
        # Trend Data Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS trend_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                week INTEGER NOT NULL,
                date DATE NOT NULL,
                topic TEXT NOT NULL,
                search_volume_index REAL,
                growth_rate REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # A/B Test Results Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ab_test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                variable TEXT NOT NULL,
                group_a TEXT NOT NULL,
                group_b TEXT NOT NULL,
                mean_a REAL,
                mean_b REAL,
                p_value REAL,
                significant BOOLEAN,
                winner TEXT,
                test_date DATE DEFAULT CURRENT_DATE
            )
        """)
        
        # Recommendations Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS recommendations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                week_start DATE NOT NULL,
                top_topics TEXT,
                best_format TEXT,
                best_hook TEXT,
                best_posting_time TEXT,
                growth_lever TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        self.conn.commit()
    
    def insert_content_performance(self, df: pd.DataFrame) -> int:
        """Insert content performance data"""
        df.to_sql('content_performance', self.conn, if_exists='append', index=False)
        return len(df)
    
    def insert_sentiment_data(self, df: pd.DataFrame) -> int:
        """Insert sentiment analysis data"""
        df.to_sql('sentiment_analysis', self.conn, if_exists='append', index=False)
        return len(df)
    
    def insert_trend_data(self, df: pd.DataFrame) -> int:
        """Insert trend data"""
        df.to_sql('trend_data', self.conn, if_exists='append', index=False)
        return len(df)
    
    def get_content_performance(self, 
                                start_date: Optional[str] = None,
                                end_date: Optional[str] = None,
                                platform: Optional[str] = None,
                                topic: Optional[str] = None) -> pd.DataFrame:
        """Retrieve content performance data with filters"""
        query = "SELECT * FROM content_performance WHERE 1=1"
        params = []
        
        if start_date:
            query += " AND date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND date <= ?"
            params.append(end_date)
        if platform:
            query += " AND platform = ?"
            params.append(platform)
        if topic:
            query += " AND topic = ?"
            params.append(topic)
        
        return pd.read_sql_query(query, self.conn, params=params)
    
    def get_sentiment_by_topic(self, topic: str) -> pd.DataFrame:
        """Get sentiment analysis for a specific topic"""
        query = """
            SELECT sa.* FROM sentiment_analysis sa
            JOIN content_performance cp ON sa.post_id = cp.post_id
            WHERE cp.topic = ?
        """
        return pd.read_sql_query(query, self.conn, params=[topic])
    
    def get_trend_data(self, weeks: int = 12) -> pd.DataFrame:
        """Get recent trend data"""
        query = "SELECT * FROM trend_data ORDER BY date DESC LIMIT ?"
        return pd.read_sql_query(query, self.conn, params=[weeks * 12])
    
    def save_ab_test_results(self, results: pd.DataFrame) -> int:
        """Save A/B test results"""
        results.to_sql('ab_test_results', self.conn, if_exists='append', index=False)
        return len(results)
    
    def save_recommendations(self, recommendations: Dict[str, Any]) -> int:
        """Save weekly recommendations"""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO recommendations 
            (week_start, top_topics, best_format, best_hook, best_posting_time, growth_lever)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            datetime.now().date(),
            str(recommendations.get('top_topics', [])),
            recommendations.get('best_format', ''),
            recommendations.get('best_hook', ''),
            recommendations.get('best_posting_time', ''),
            recommendations.get('growth_lever', '')
        ))
        self.conn.commit()
        return cursor.lastrowid
    
    def get_latest_recommendations(self) -> Dict[str, Any]:
        """Get the most recent recommendations"""
        query = "SELECT * FROM recommendations ORDER BY created_at DESC LIMIT 1"
        df = pd.read_sql_query(query, self.conn)
        if len(df) > 0:
            return df.iloc[0].to_dict()
        return {}
    
    def execute_query(self, query: str, params: Optional[List] = None) -> pd.DataFrame:
        """Execute custom SQL query"""
        return pd.read_sql_query(query, self.conn, params=params or [])
    
    def backup_database(self, backup_path: str):
        """Create a backup of the database"""
        import shutil
        shutil.copy2(self.db_path, backup_path)
    
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


if __name__ == "__main__":
    # Test database operations
    db = DatabaseManager()
    print("✅ Database initialized successfully")
    print(f"📁 Database location: {db.db_path}")
    
    # Test query
    try:
        result = db.execute_query("SELECT name FROM sqlite_master WHERE type='table'")
        print(f"\n📊 Tables created: {len(result)}")
        print(result['name'].tolist())
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        db.close()

