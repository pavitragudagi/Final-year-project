"""
Module 2: Virality Prediction Engine
Calculates a weighted Viral Coefficient for each piece of content.
Weights high-value actions (Shares & Saves) over passive ones (Likes).
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression


WEIGHTS = {
    "shares":    0.40,
    "saves":     0.30,
    "comments":  0.15,
    "likes":     0.10,
    "retention": 0.05,
}


def compute_viral_coefficient(df: pd.DataFrame) -> pd.DataFrame:
    """
    Viral Coefficient = weighted sum of normalised engagement signals.
    Each signal is min-max scaled per dataset so scores are 0-1.
    """
    df = df.copy()
    scaler = MinMaxScaler()

    signals = ["shares", "saves", "comments", "likes", "retention_rate"]
    normed  = scaler.fit_transform(df[signals])
    normed_df = pd.DataFrame(normed, columns=signals, index=df.index)

    w = WEIGHTS
    df["viral_coefficient"] = (
        normed_df["shares"]         * w["shares"]    +
        normed_df["saves"]          * w["saves"]     +
        normed_df["comments"]       * w["comments"]  +
        normed_df["likes"]          * w["likes"]     +
        normed_df["retention_rate"] * w["retention"]
    ).round(4)

    # Tier labelling
    df["viral_tier"] = pd.cut(
        df["viral_coefficient"],
        bins=[0, 0.25, 0.50, 0.75, 1.01],
        labels=["Low", "Medium", "High", "Viral"],
        right=False
    )
    return df


def topic_virality_ranking(df: pd.DataFrame) -> pd.DataFrame:
    """Rank topics by their mean Viral Coefficient"""
    ranked = (
        df.groupby("topic")
          .agg(
              mean_vc=("viral_coefficient", "mean"),
              max_vc=("viral_coefficient", "max"),
              viral_posts=("viral_tier", lambda x: (x == "Viral").sum()),
              total_posts=("post_id", "count"),
          )
          .round(4)
          .reset_index()
          .sort_values("mean_vc", ascending=False)
    )
    ranked["viral_rate_%"] = (ranked["viral_posts"] / ranked["total_posts"] * 100).round(1)
    return ranked


def predict_virality(df: pd.DataFrame, new_post: dict) -> float:
    """
    Simple regression to predict viral coefficient for a new post config.
    new_post = {topic, format, hook_type, posting_time}
    """
    feature_cols = ["topic", "format", "hook_type", "posting_time"]
    df_enc = pd.get_dummies(df[feature_cols])
    X = df_enc
    y = df["viral_coefficient"]

    model = LinearRegression().fit(X, y)

    new_df = pd.DataFrame([new_post])
    new_enc = pd.get_dummies(new_df[feature_cols]).reindex(columns=df_enc.columns, fill_value=0)
    prediction = float(model.predict(new_enc)[0])
    return round(max(0, min(1, prediction)), 4)


if __name__ == "__main__":
    from module1_tracker import generate_dataset
    df = generate_dataset(200)
    df = compute_viral_coefficient(df)
    ranking = topic_virality_ranking(df)
    print("=== Topic Virality Ranking ===")
    print(ranking.to_string(index=False))
