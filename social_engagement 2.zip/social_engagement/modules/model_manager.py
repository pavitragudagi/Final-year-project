"""
Module: Model Manager
ML model persistence and management
Handles saving, loading, and versioning of trained models
"""

import joblib
import json
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, Optional
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.logger import setup_logger

logger = setup_logger("model_manager")


class ModelManager:
    """Manages machine learning model persistence"""
    
    def __init__(self, models_dir: str = "models"):
        """
        Initialize model manager
        
        Args:
            models_dir: Directory to store models
        """
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Model manager initialized with directory: {self.models_dir}")
    
    def save_model(self, model: Any, model_name: str, 
                   metadata: Optional[Dict] = None, version: Optional[str] = None) -> str:
        """
        Save a trained model with metadata
        
        Args:
            model: Trained model object
            model_name: Name of the model
            metadata: Additional metadata (metrics, parameters, etc.)
            version: Model version (auto-generated if not provided)
            
        Returns:
            Path to saved model
        """
        if version is None:
            version = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        model_filename = f"{model_name}_v{version}.joblib"
        model_path = self.models_dir / model_filename
        
        # Save model
        try:
            joblib.dump(model, model_path)
            logger.info(f"Model saved: {model_path}")
            
            # Save metadata
            if metadata is None:
                metadata = {}
            
            metadata.update({
                'model_name': model_name,
                'version': version,
                'saved_at': datetime.now().isoformat(),
                'model_type': type(model).__name__
            })
            
            metadata_path = self.models_dir / f"{model_name}_v{version}_metadata.json"
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            
            logger.info(f"Metadata saved: {metadata_path}")
            return str(model_path)
            
        except Exception as e:
            logger.error(f"Error saving model: {e}")
            raise
    
    def load_model(self, model_name: str, version: Optional[str] = None) -> Any:
        """
        Load a saved model
        
        Args:
            model_name: Name of the model
            version: Model version (loads latest if not provided)
            
        Returns:
            Loaded model object
        """
        try:
            if version is None:
                # Find latest version
                model_files = list(self.models_dir.glob(f"{model_name}_v*.joblib"))
                if not model_files:
                    raise FileNotFoundError(f"No models found for {model_name}")
                model_path = max(model_files, key=lambda p: p.stat().st_mtime)
            else:
                model_path = self.models_dir / f"{model_name}_v{version}.joblib"
            
            if not model_path.exists():
                raise FileNotFoundError(f"Model not found: {model_path}")
            
            model = joblib.load(model_path)
            logger.info(f"Model loaded: {model_path}")
            return model
            
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            raise
    
    def load_metadata(self, model_name: str, version: Optional[str] = None) -> Dict:
        """
        Load model metadata
        
        Args:
            model_name: Name of the model
            version: Model version (loads latest if not provided)
            
        Returns:
            Metadata dictionary
        """
        try:
            if version is None:
                # Find latest version
                metadata_files = list(self.models_dir.glob(f"{model_name}_v*_metadata.json"))
                if not metadata_files:
                    return {}
                metadata_path = max(metadata_files, key=lambda p: p.stat().st_mtime)
            else:
                metadata_path = self.models_dir / f"{model_name}_v{version}_metadata.json"
            
            if not metadata_path.exists():
                return {}
            
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
            
            return metadata
            
        except Exception as e:
            logger.error(f"Error loading metadata: {e}")
            return {}
    
    def list_models(self) -> Dict[str, list]:
        """
        List all saved models
        
        Returns:
            Dictionary mapping model names to list of versions
        """
        models = {}
        
        for model_file in self.models_dir.glob("*.joblib"):
            # Parse model name and version from filename
            filename = model_file.stem
            if '_v' in filename:
                model_name, version = filename.rsplit('_v', 1)
                if model_name not in models:
                    models[model_name] = []
                models[model_name].append(version)
        
        # Sort versions for each model
        for model_name in models:
            models[model_name].sort(reverse=True)
        
        return models
    
    def delete_model(self, model_name: str, version: str) -> bool:
        """
        Delete a specific model version
        
        Args:
            model_name: Name of the model
            version: Model version to delete
            
        Returns:
            True if successful, False otherwise
        """
        try:
            model_path = self.models_dir / f"{model_name}_v{version}.joblib"
            metadata_path = self.models_dir / f"{model_name}_v{version}_metadata.json"
            
            deleted = False
            if model_path.exists():
                model_path.unlink()
                deleted = True
                logger.info(f"Deleted model: {model_path}")
            
            if metadata_path.exists():
                metadata_path.unlink()
                logger.info(f"Deleted metadata: {metadata_path}")
            
            return deleted
            
        except Exception as e:
            logger.error(f"Error deleting model: {e}")
            return False
    
    def get_model_info(self, model_name: str, version: Optional[str] = None) -> Dict:
        """
        Get comprehensive information about a model
        
        Args:
            model_name: Name of the model
            version: Model version (latest if not provided)
            
        Returns:
            Dictionary with model information
        """
        metadata = self.load_metadata(model_name, version)
        
        if version is None:
            model_files = list(self.models_dir.glob(f"{model_name}_v*.joblib"))
            if model_files:
                model_path = max(model_files, key=lambda p: p.stat().st_mtime)
                version = model_path.stem.split('_v')[1]
        
        if version:
            model_path = self.models_dir / f"{model_name}_v{version}.joblib"
            if model_path.exists():
                file_size = model_path.stat().st_size / 1024  # KB
                metadata['file_size_kb'] = round(file_size, 2)
                metadata['file_path'] = str(model_path)
        
        return metadata


class ViralityModelManager(ModelManager):
    """Specialized manager for virality prediction models"""
    
    def save_virality_model(self, model: Any, metrics: Dict, 
                           feature_names: list, version: Optional[str] = None) -> str:
        """
        Save virality prediction model with specific metadata
        
        Args:
            model: Trained model
            metrics: Performance metrics (accuracy, R2, etc.)
            feature_names: List of feature names used
            version: Model version
            
        Returns:
            Path to saved model
        """
        metadata = {
            'metrics': metrics,
            'feature_names': feature_names,
            'model_purpose': 'virality_prediction'
        }
        
        return self.save_model(model, 'virality_predictor', metadata, version)
    
    def load_virality_model(self, version: Optional[str] = None):
        """Load virality prediction model"""
        return self.load_model('virality_predictor', version)


class SentimentModelManager(ModelManager):
    """Specialized manager for sentiment analysis models"""
    
    def save_sentiment_model(self, model: Any, accuracy: float,
                            label_mapping: Dict, version: Optional[str] = None) -> str:
        """
        Save sentiment analysis model
        
        Args:
            model: Trained model
            accuracy: Model accuracy
            label_mapping: Mapping of labels
            version: Model version
            
        Returns:
            Path to saved model
        """
        metadata = {
            'accuracy': accuracy,
            'label_mapping': label_mapping,
            'model_purpose': 'sentiment_analysis'
        }
        
        return self.save_model(model, 'sentiment_analyzer', metadata, version)
    
    def load_sentiment_model(self, version: Optional[str] = None):
        """Load sentiment analysis model"""
        return self.load_model('sentiment_analyzer', version)


if __name__ == "__main__":
    # Test model manager
    print("💾 Testing Model Manager...")
    
    manager = ModelManager()
    
    # Create a dummy model
    from sklearn.linear_model import LinearRegression
    import numpy as np
    
    X = np.array([[1, 2], [3, 4], [5, 6]])
    y = np.array([1, 2, 3])
    model = LinearRegression().fit(X, y)
    
    # Save model
    try:
        path = manager.save_model(
            model, 
            'test_model',
            metadata={'accuracy': 0.95, 'features': ['x1', 'x2']}
        )
        print(f"✅ Model saved: {path}")
        
        # Load model
        loaded_model = manager.load_model('test_model')
        print(f"✅ Model loaded successfully")
        
        # List models
        models = manager.list_models()
        print(f"✅ Found {len(models)} model(s)")
        
        # Get model info
        info = manager.get_model_info('test_model')
        print(f"✅ Model info: {info}")
        
    except Exception as e:
        print(f"❌ Error: {e}")

