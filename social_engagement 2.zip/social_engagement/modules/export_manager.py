"""
Module: Export Manager
Handles data export to various formats (CSV, Excel, JSON, PDF)
"""

import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
import json
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.logger import setup_logger

logger = setup_logger("export_manager")


class ExportManager:
    """Manages data export to multiple formats"""
    
    def __init__(self, output_dir: str = "data/exports"):
        """
        Initialize export manager
        
        Args:
            output_dir: Directory for exported files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Export manager initialized with directory: {self.output_dir}")
    
    def _generate_filename(self, base_name: str, extension: str) -> Path:
        """Generate timestamped filename"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{base_name}_{timestamp}.{extension}"
        return self.output_dir / filename
    
    def export_to_csv(self, data: pd.DataFrame, filename: str = "export") -> str:
        """
        Export DataFrame to CSV
        
        Args:
            data: DataFrame to export
            filename: Base filename (without extension)
            
        Returns:
            Path to exported file
        """
        try:
            filepath = self._generate_filename(filename, "csv")
            data.to_csv(filepath, index=False)
            logger.info(f"Exported to CSV: {filepath}")
            return str(filepath)
        except Exception as e:
            logger.error(f"Error exporting to CSV: {e}")
            raise
    
    def export_to_excel(self, data: pd.DataFrame, filename: str = "export",
                       sheet_name: str = "Data") -> str:
        """
        Export DataFrame to Excel with formatting
        
        Args:
            data: DataFrame to export
            filename: Base filename (without extension)
            sheet_name: Name of the Excel sheet
            
        Returns:
            Path to exported file
        """
        try:
            filepath = self._generate_filename(filename, "xlsx")
            
            with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
                data.to_excel(writer, sheet_name=sheet_name, index=False)
                
                # Auto-adjust column widths
                worksheet = writer.sheets[sheet_name]
                for idx, col in enumerate(data.columns):
                    max_length = max(
                        data[col].astype(str).apply(len).max(),
                        len(str(col))
                    )
                    worksheet.column_dimensions[chr(65 + idx)].width = min(max_length + 2, 50)
            
            logger.info(f"Exported to Excel: {filepath}")
            return str(filepath)
        except Exception as e:
            logger.error(f"Error exporting to Excel: {e}")
            raise
    
    def export_to_json(self, data: Any, filename: str = "export") -> str:
        """
        Export data to JSON
        
        Args:
            data: Data to export (DataFrame, dict, or list)
            filename: Base filename (without extension)
            
        Returns:
            Path to exported file
        """
        try:
            filepath = self._generate_filename(filename, "json")
            
            if isinstance(data, pd.DataFrame):
                data_dict = data.to_dict(orient='records')
            else:
                data_dict = data
            
            with open(filepath, 'w') as f:
                json.dump(data_dict, f, indent=2, default=str)
            
            logger.info(f"Exported to JSON: {filepath}")
            return str(filepath)
        except Exception as e:
            logger.error(f"Error exporting to JSON: {e}")
            raise
    
    def export_to_pdf(self, content: str, filename: str = "report") -> str:
        """
        Export text content to PDF
        
        Args:
            content: Text content to export
            filename: Base filename (without extension)
            
        Returns:
            Path to exported file
        """
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            
            filepath = self._generate_filename(filename, "pdf")
            
            doc = SimpleDocTemplate(str(filepath), pagesize=letter)
            styles = getSampleStyleSheet()
            story = []
            
            # Split content into paragraphs
            for line in content.split('\n'):
                if line.strip():
                    para = Paragraph(line, styles['Normal'])
                    story.append(para)
                    story.append(Spacer(1, 12))
            
            doc.build(story)
            logger.info(f"Exported to PDF: {filepath}")
            return str(filepath)
        except ImportError:
            logger.error("reportlab not installed. Install with: pip install reportlab")
            raise
        except Exception as e:
            logger.error(f"Error exporting to PDF: {e}")
            raise
    
    def export_multi_sheet_excel(self, data_dict: Dict[str, pd.DataFrame],
                                 filename: str = "multi_sheet_export") -> str:
        """
        Export multiple DataFrames to different Excel sheets
        
        Args:
            data_dict: Dictionary mapping sheet names to DataFrames
            filename: Base filename (without extension)
            
        Returns:
            Path to exported file
        """
        try:
            filepath = self._generate_filename(filename, "xlsx")
            
            with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
                for sheet_name, df in data_dict.items():
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            logger.info(f"Exported multi-sheet Excel: {filepath}")
            return str(filepath)
        except Exception as e:
            logger.error(f"Error exporting multi-sheet Excel: {e}")
            raise


class ReportGenerator:
    """Generates formatted reports from analytics data"""
    
    def __init__(self, export_manager: Optional[ExportManager] = None):
        """Initialize report generator"""
        self.export_manager = export_manager or ExportManager()
    
    def generate_weekly_report(self, recommendations: Dict, 
                              topic_virality: pd.DataFrame,
                              sentiment_data: pd.DataFrame) -> str:
        """
        Generate comprehensive weekly strategy report
        
        Args:
            recommendations: Weekly recommendations dict
            topic_virality: Topic virality DataFrame
            sentiment_data: Sentiment analysis DataFrame
            
        Returns:
            Path to generated report
        """
        report_lines = [
            "=" * 80,
            "WEEKLY CONTENT STRATEGY REPORT",
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "=" * 80,
            "",
            "TOP RECOMMENDED TOPICS",
            "-" * 80,
        ]
        
        for i, topic in enumerate(recommendations.get('top_topics', []), 1):
            report_lines.append(
                f"{i}. {topic['topic']}\n"
                f"   Composite Score: {topic['composite_score']:.3f}\n"
                f"   Relatable: {topic['relatable_%']:.1f}%\n"
            )
        
        report_lines.extend([
            "",
            "OPTIMAL EXECUTION SETTINGS",
            "-" * 80,
            f"Format: {recommendations.get('best_format', 'N/A')}",
            f"Hook Type: {recommendations.get('best_hook', 'N/A')}",
            f"Posting Time: {recommendations.get('best_posting_time', 'N/A')}",
            f"Frequency: {recommendations.get('posting_frequency', 'N/A')}",
            f"Growth Lever: {recommendations.get('growth_lever', 'N/A')}",
            "",
            "TOPIC VIRALITY RANKING",
            "-" * 80,
        ])
        
        for _, row in topic_virality.head(10).iterrows():
            report_lines.append(
                f"{row['topic']}: VC={row['mean_vc']:.4f}, "
                f"Viral Rate={row['viral_rate_%']:.1f}%"
            )
        
        report_lines.extend([
            "",
            "SENTIMENT ANALYSIS SUMMARY",
            "-" * 80,
        ])
        
        for _, row in sentiment_data.head(10).iterrows():
            report_lines.append(
                f"{row['topic']}: Relatable={row['relatable_%']:.1f}%, "
                f"Neutral={row['neutral_%']:.1f}%, "
                f"Not Resonating={row['not_resonating_%']:.1f}%"
            )
        
        report_lines.extend([
            "",
            "=" * 80,
            "End of Report",
            "=" * 80,
        ])
        
        report_content = "\n".join(report_lines)
        
        # Export to both text and PDF
        text_path = self.export_manager._generate_filename("weekly_report", "txt")
        with open(text_path, 'w') as f:
            f.write(report_content)
        
        logger.info(f"Weekly report generated: {text_path}")
        
        try:
            pdf_path = self.export_manager.export_to_pdf(report_content, "weekly_report")
            logger.info(f"PDF report generated: {pdf_path}")
            return pdf_path
        except:
            return str(text_path)
    
    def generate_performance_summary(self, df: pd.DataFrame) -> str:
        """
        Generate performance summary report
        
        Args:
            df: Content performance DataFrame
            
        Returns:
            Path to generated report
        """
        summary = {
            'total_posts': len(df),
            'total_reach': df['reach'].sum(),
            'total_impressions': df['impressions'].sum(),
            'total_engagement': df['likes'].sum() + df['comments'].sum() + df['shares'].sum(),
            'avg_viral_coefficient': df['viral_coefficient'].mean(),
            'viral_posts': (df['viral_tier'] == 'Viral').sum(),
            'top_performing_topic': df.groupby('topic')['viral_coefficient'].mean().idxmax(),
        }
        
        report_lines = [
            "PERFORMANCE SUMMARY",
            "=" * 60,
            f"Total Posts: {summary['total_posts']:,}",
            f"Total Reach: {summary['total_reach']:,}",
            f"Total Impressions: {summary['total_impressions']:,}",
            f"Total Engagement: {summary['total_engagement']:,}",
            f"Average Viral Coefficient: {summary['avg_viral_coefficient']:.4f}",
            f"Viral Posts: {summary['viral_posts']} ({summary['viral_posts']/summary['total_posts']*100:.1f}%)",
            f"Top Performing Topic: {summary['top_performing_topic']}",
            "=" * 60,
        ]
        
        report_content = "\n".join(report_lines)
        
        filepath = self.export_manager._generate_filename("performance_summary", "txt")
        with open(filepath, 'w') as f:
            f.write(report_content)
        
        logger.info(f"Performance summary generated: {filepath}")
        return str(filepath)


if __name__ == "__main__":
    # Test export manager
    print("📤 Testing Export Manager...")
    
    export_mgr = ExportManager()
    
    # Create sample data
    sample_data = pd.DataFrame({
        'topic': ['Social Anxiety', 'Dating Struggles', 'Overthinking'],
        'viral_coefficient': [0.85, 0.72, 0.68],
        'engagement': [1500, 1200, 1100]
    })
    
    try:
        # Test CSV export
        csv_path = export_mgr.export_to_csv(sample_data, "test_export")
        print(f"✅ CSV exported: {csv_path}")
        
        # Test Excel export
        excel_path = export_mgr.export_to_excel(sample_data, "test_export")
        print(f"✅ Excel exported: {excel_path}")
        
        # Test JSON export
        json_path = export_mgr.export_to_json(sample_data, "test_export")
        print(f"✅ JSON exported: {json_path}")
        
        print("\n✅ All export tests passed!")
        
    except Exception as e:
        print(f"❌ Error: {e}")

