"""
Module 3: Audience Sentiment Analyzer (NLP Module)
Processes user comments to validate "Problem Awareness."
Tags comments as Relatable / Neutral / Not Resonating.
Uses TextBlob polarity + keyword-trigger scoring.
"""

import random
import re
from dataclasses import dataclass
from typing import List, Dict

try:
    from textblob import TextBlob
    HAS_TEXTBLOB = True
except ImportError:
    HAS_TEXTBLOB = False

import pandas as pd


# ── Linguistic triggers that signal Problem Awareness ──────────────────────────
RELATABLE_TRIGGERS = [
    r"\bthis is me\b", r"\bstory of my life\b", r"\bso relatable\b",
    r"\bi needed this\b", r"\bthank you for this\b", r"\bwhy is this so accurate\b",
    r"\bsaved\b", r"\bsharing this\b", r"\bfelt this\b", r"\bcrying\b",
    r"\bexactly how i feel\b", r"\bno one talks about this\b",
    r"\bthought i was alone\b", r"\bme every day\b", r"\bthis hit different\b",
    r"\bpov: me\b", r"\bscreaming\b", r"\bwho made this\b", r"\bwow\b.*\baccurate\b",
]
NEUTRAL_TRIGGERS   = [r"\binteresting\b", r"\bok\b", r"\bgood post\b", r"\bnice\b", r"\bcool\b"]
NEGATIVE_TRIGGERS  = [r"\bdisagree\b", r"\bnot relatable\b", r"\boverrated\b", r"\bcringe\b"]


# ── Sample comment templates per topic ────────────────────────────────────────
COMMENT_TEMPLATES = {
    "Social Anxiety": [
        "this is literally me at every party 😭",
        "thought i was the only one who felt this way",
        "saved this for when i need it",
        "ok but why does this hit so hard",
        "my therapist sent me this and i cried",
        "sharing this with my best friend rn",
        "no one talks about this enough fr",
        "I just like scrolling tbh",
        "interesting perspective I guess",
    ],
    "Dating Struggles": [
        "story of my entire life omg",
        "this is literally every situationship ever",
        "felt this in my soul 💔",
        "why is this so accurate it hurts",
        "sending this to my situationship",
        "ok but real talk this helped me",
        "lol true ig",
        "nice content",
    ],
    "Overthinking": [
        "brain at 3am: let me replay that",
        "this is me every single night 😭",
        "thought i was broken til i saw this",
        "saving this to send my brain",
        "so accurate i had to screenshot",
        "my therapist will hear about this",
        "yeah overthinking is a thing lol",
        "ok",
    ],
    "DEFAULT": [
        "this hit different today",
        "why is this so me",
        "needed to hear this rn",
        "ok interesting point",
        "cool post",
        "saving this",
        "sharing with my friends",
        "eh not that relatable tbh",
    ]
}


def generate_comments(topic: str, n: int = 15) -> List[str]:
    """Simulate n comments for a given topic"""
    pool = COMMENT_TEMPLATES.get(topic, COMMENT_TEMPLATES["DEFAULT"])
    return [random.choice(pool) for _ in range(n)]


@dataclass
class CommentAnalysis:
    comment: str
    label: str          # Relatable / Neutral / Not Resonating
    trigger_score: float
    polarity: float
    compound_score: float


def _trigger_score(text: str) -> float:
    t = text.lower()
    score = 0.0
    for pat in RELATABLE_TRIGGERS:
        if re.search(pat, t):
            score += 1.0
    for pat in NEGATIVE_TRIGGERS:
        if re.search(pat, t):
            score -= 0.5
    for pat in NEUTRAL_TRIGGERS:
        if re.search(pat, t):
            score -= 0.1
    return round(score, 2)


def _polarity(text: str) -> float:
    if HAS_TEXTBLOB:
        return round(TextBlob(text).sentiment.polarity, 3)
    # Fallback: crude word count
    pos = ["love","great","amazing","helped","thank","needed","saved","wow"]
    neg = ["hate","bad","cringe","disagree","wrong","overrated"]
    words = text.lower().split()
    score = sum(1 for w in words if w in pos) - sum(1 for w in words if w in neg)
    return round(max(-1, min(1, score * 0.25)), 3)


def analyse_comment(text: str) -> CommentAnalysis:
    ts   = _trigger_score(text)
    pol  = _polarity(text)
    comp = round(ts * 0.7 + pol * 0.3, 3)

    if comp >= 0.5:
        label = "Relatable"
    elif comp <= -0.2:
        label = "Not Resonating"
    else:
        label = "Neutral"

    return CommentAnalysis(comment=text, label=label,
                           trigger_score=ts, polarity=pol, compound_score=comp)


def analyse_post_comments(topic: str, n_comments: int = 20) -> pd.DataFrame:
    """Generate + analyse n comments for a post topic"""
    comments = generate_comments(topic, n_comments)
    results  = [analyse_comment(c) for c in comments]
    df = pd.DataFrame([vars(r) for r in results])
    return df


def sentiment_summary(df: pd.DataFrame) -> Dict[str, float]:
    counts = df["label"].value_counts(normalize=True).to_dict()
    return {k: round(v * 100, 1) for k, v in counts.items()}


def bulk_sentiment_by_topic(topics: List[str], n_per_topic: int = 30) -> pd.DataFrame:
    """Run sentiment analysis across all topics"""
    rows = []
    for topic in topics:
        df = analyse_post_comments(topic, n_per_topic)
        summ = sentiment_summary(df)
        rows.append({
            "topic": topic,
            "relatable_%": summ.get("Relatable", 0),
            "neutral_%":   summ.get("Neutral", 0),
            "not_resonating_%": summ.get("Not Resonating", 0),
            "problem_awareness_score": round(summ.get("Relatable", 0) / 100, 3),
        })
    return pd.DataFrame(rows).sort_values("relatable_%", ascending=False)


if __name__ == "__main__":
    from module1_tracker import TOPICS
    results = bulk_sentiment_by_topic(TOPICS)
    print("=== Sentiment Analysis by Topic ===")
    print(results.to_string(index=False))
