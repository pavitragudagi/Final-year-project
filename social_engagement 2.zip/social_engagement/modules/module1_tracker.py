"""
Module 1: Content Performance Tracker (Data Extraction Engine)
Simulates API data extraction & generates structured dataset
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

TOPICS = [
    "Social Anxiety", "Dating Struggles", "Overthinking", "Imposter Syndrome",
    "Burnout", "Loneliness", "Self-Doubt", "People Pleasing",
    "Fear of Failure", "Morning Routines", "Career Anxiety", "Body Image"
]

FORMATS = ["Short Reel (<30s)", "Long Reel (30-60s)", "Carousel", "Static Post", "Story"]
HOOKS = ["Visual Hook", "Text Hook", "Question Hook", "Story Hook"]
POSTING_TIMES = ["7-9 AM", "12-2 PM", "6-9 PM", "10 PM+"]
PLATFORMS = ["Instagram", "YouTube"]

def generate_dataset(n=200, seed=42):
    """Generate realistic synthetic content performance dataset"""
    np.random.seed(seed)
    random.seed(seed)
    
    rows = []
    start_date = datetime(2024, 6, 1)
    
    topic_weights = {
        "Social Anxiety": 1.45, "Dating Struggles": 1.30, "Overthinking": 1.25,
        "Imposter Syndrome": 1.20, "Burnout": 1.15, "Loneliness": 1.35,
        "Self-Doubt": 1.10, "People Pleasing": 1.05,
        "Fear of Failure": 1.00, "Morning Routines": 0.85,
        "Career Anxiety": 0.90, "Body Image": 1.00
    }
    
    for i in range(n):
        topic = random.choice(TOPICS)
        fmt = random.choice(FORMATS)
        hook = random.choice(HOOKS)
        post_time = random.choice(POSTING_TIMES)
        platform = random.choice(PLATFORMS)
        tw = topic_weights[topic]
        
        # Format multipliers
        fmt_mult = {"Short Reel (<30s)": 1.30, "Long Reel (30-60s)": 1.10,
                    "Carousel": 1.20, "Static Post": 0.85, "Story": 0.75}.get(fmt, 1.0)
        
        # Hook multipliers
        hook_mult = {"Visual Hook": 1.25, "Question Hook": 1.15,
                     "Story Hook": 1.10, "Text Hook": 0.90}.get(hook, 1.0)
        
        # Time multipliers
        time_mult = {"6-9 PM": 1.30, "12-2 PM": 1.15,
                     "7-9 AM": 1.05, "10 PM+": 0.90}.get(post_time, 1.0)
        
        base_reach = int(np.random.lognormal(9, 1.2) * tw * fmt_mult)
        impressions = int(base_reach * np.random.uniform(1.2, 2.5))
        likes = int(base_reach * np.random.uniform(0.04, 0.12) * tw)
        comments = int(likes * np.random.uniform(0.05, 0.20) * hook_mult)
        shares = int(likes * np.random.uniform(0.08, 0.25) * tw * hook_mult)
        saves = int(likes * np.random.uniform(0.10, 0.35) * tw * fmt_mult)
        retention = round(min(np.random.normal(0.42, 0.14) * fmt_mult * time_mult, 0.98), 3)
        followers_gained = int(np.random.exponential(12) * tw * fmt_mult)
        
        post_date = start_date + timedelta(days=i * random.uniform(0.5, 3.5))
        
        rows.append({
            "post_id": f"POST_{i+1:04d}",
            "platform": platform,
            "topic": topic,
            "format": fmt,
            "hook_type": hook,
            "posting_time": post_time,
            "date": post_date.strftime("%Y-%m-%d"),
            "reach": base_reach,
            "impressions": impressions,
            "likes": likes,
            "comments": comments,
            "shares": shares,
            "saves": saves,
            "retention_rate": retention,
            "followers_gained": followers_gained,
        })
    
    df = pd.DataFrame(rows)
    df = df.sort_values("date").reset_index(drop=True)
    return df


def get_performance_summary(df):
    """Aggregate performance metrics by topic"""
    summary = df.groupby("topic").agg(
        posts=("post_id", "count"),
        avg_reach=("reach", "mean"),
        avg_likes=("likes", "mean"),
        avg_shares=("shares", "mean"),
        avg_saves=("saves", "mean"),
        avg_retention=("retention_rate", "mean"),
        total_followers=("followers_gained", "sum"),
    ).round(1).reset_index()
    return summary.sort_values("avg_shares", ascending=False)


if __name__ == "__main__":
    df = generate_dataset(200)
    df.to_csv("data/content_performance.csv", index=False)
    print(f"Generated {len(df)} records")
    print(df.head())
