"""
Module 4: A/B Testing Framework
Runs controlled experiments on content variables.
Tests format, hook type, and posting time.
Computes statistical significance via t-test / z-test.
"""

import pandas as pd
import numpy as np
from scipy import stats
from itertools import combinations
from typing import Tuple, Dict, List


def run_ab_test(df: pd.DataFrame, variable: str,
                metric: str = "viral_coefficient",
                min_samples: int = 5) -> pd.DataFrame:
    """
    Pairwise A/B test across all levels of `variable`.
    Returns a DataFrame with effect size, p-value, and significance flag.
    """
    groups = df.groupby(variable)[metric].apply(list).to_dict()
    groups = {k: v for k, v in groups.items() if len(v) >= min_samples}

    results = []
    for a, b in combinations(groups.keys(), 2):
        va, vb = np.array(groups[a]), np.array(groups[b])
        t_stat, p_val = stats.ttest_ind(va, vb, equal_var=False)
        cohen_d = (va.mean() - vb.mean()) / (
            np.sqrt((va.std()**2 + vb.std()**2) / 2) + 1e-9
        )
        results.append({
            "group_A": a,
            "group_B": b,
            "mean_A": round(va.mean(), 4),
            "mean_B": round(vb.mean(), 4),
            "diff": round(vb.mean() - va.mean(), 4),
            "cohen_d": round(cohen_d, 3),
            "p_value": round(p_val, 4),
            "significant": p_val < 0.05,
            "winner": b if vb.mean() > va.mean() else a,
        })

    out = pd.DataFrame(results)
    out["variable"] = variable
    return out.sort_values("p_value")


def full_ab_report(df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    """Run A/B tests for all content variables"""
    variables = ["format", "hook_type", "posting_time"]
    return {v: run_ab_test(df, v) for v in variables}


def best_configuration(df: pd.DataFrame) -> Dict[str, str]:
    """
    Return the single best level for each variable by mean viral_coefficient.
    """
    best = {}
    for var in ["format", "hook_type", "posting_time"]:
        means = df.groupby(var)["viral_coefficient"].mean()
        best[var] = means.idxmax()
    return best


def segment_performance(df: pd.DataFrame) -> pd.DataFrame:
    """Cross-tabulate format × posting_time mean VC"""
    pivot = df.pivot_table(
        values="viral_coefficient",
        index="format",
        columns="posting_time",
        aggfunc="mean"
    ).round(4)
    return pivot


if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from module1_tracker import generate_dataset
    from module2_virality import compute_viral_coefficient

    df = compute_viral_coefficient(generate_dataset(200))

    print("=== Best Configuration ===")
    print(best_configuration(df))

    print("\n=== A/B Test: Format ===")
    report = run_ab_test(df, "format")
    print(report[["group_A","group_B","mean_A","mean_B","p_value","significant","winner"]].to_string(index=False))
