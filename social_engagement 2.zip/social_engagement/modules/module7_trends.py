"""
Module 7: Trend Forecasting Module
Analyses external hashtag/keyword trends to predict rising "relatable struggles"
before they become mainstream.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random


TREND_TOPICS = {
    "Social Anxiety":      {"current_volume": 2.8, "growth_rate": 0.18, "peak_week": 3},
    "Dating Struggles":    {"current_volume": 2.2, "growth_rate": 0.14, "peak_week": 5},
    "Overthinking":        {"current_volume": 3.1, "growth_rate": 0.08, "peak_week": 8},
    "Imposter Syndrome":   {"current_volume": 1.5, "growth_rate": 0.28, "peak_week": 2},  # Rising fast!
    "Burnout":             {"current_volume": 2.5, "growth_rate": 0.10, "peak_week": 6},
    "Loneliness":          {"current_volume": 1.8, "growth_rate": 0.22, "peak_week": 2},  # Rising fast!
    "Self-Doubt":          {"current_volume": 1.2, "growth_rate": 0.32, "peak_week": 1},  # About to trend!
    "People Pleasing":     {"current_volume": 1.0, "growth_rate": 0.35, "peak_week": 1},  # About to trend!
    "Fear of Failure":     {"current_volume": 0.9, "growth_rate": 0.15, "peak_week": 4},
    "Morning Routines":    {"current_volume": 3.5, "growth_rate": -0.02, "peak_week": 12},  # Declining
    "Career Anxiety":      {"current_volume": 1.4, "growth_rate": 0.20, "peak_week": 3},
    "Body Image":          {"current_volume": 2.0, "growth_rate": 0.05, "peak_week": 10},
}


def generate_weekly_trend_data(weeks: int = 12, seed: int = 42) -> pd.DataFrame:
    """Simulate weekly search volume index (0-10) for each topic"""
    np.random.seed(seed)
    rows = []
    start = datetime(2024, 7, 1)

    for topic, meta in TREND_TOPICS.items():
        vol = meta["current_volume"]
        gr  = meta["growth_rate"]
        for w in range(weeks):
            date = start + timedelta(weeks=w)
            noise = np.random.normal(0, 0.12)
            weekly_vol = round(min(10, max(0.1, vol * (1 + gr) ** w + noise)), 3)
            rows.append({
                "week": w + 1,
                "date": date.strftime("%Y-%m-%d"),
                "topic": topic,
                "search_volume_index": weekly_vol,
                "growth_rate": gr,
            })
    return pd.DataFrame(rows)


def identify_rising_topics(trend_df: pd.DataFrame, top_n: int = 5) -> pd.DataFrame:
    """
    Identify topics with the highest projected growth in the next 4 weeks.
    Rising = high growth rate AND not yet at peak volume (still < 7 on index).
    """
    latest = trend_df[trend_df["week"] == trend_df["week"].max()].copy()
    latest["opportunity_score"] = (
        latest["growth_rate"] * 0.6 +
        (1 - latest["search_volume_index"] / 10) * 0.4  # Lower = more headroom
    ).round(4)
    latest["status"] = latest.apply(
        lambda r: "🚀 About to trend" if r["growth_rate"] > 0.25 and r["search_volume_index"] < 2
        else "📈 Rising fast" if r["growth_rate"] > 0.15
        else "📊 Stable" if r["growth_rate"] > 0
        else "📉 Declining",
        axis=1
    )
    return latest.sort_values("opportunity_score", ascending=False).head(top_n)


def forecast_next_weeks(trend_df: pd.DataFrame, topic: str, n_weeks: int = 4) -> pd.DataFrame:
    """Simple linear extrapolation forecast for a topic"""
    topic_df = trend_df[trend_df["topic"] == topic].sort_values("week")
    last_vol = topic_df["search_volume_index"].iloc[-1]
    gr = topic_df["growth_rate"].iloc[-1]
    last_week = topic_df["week"].max()
    last_date = datetime.strptime(topic_df["date"].iloc[-1], "%Y-%m-%d")

    forecasts = []
    for i in range(1, n_weeks + 1):
        forecasts.append({
            "week": last_week + i,
            "date": (last_date + timedelta(weeks=i)).strftime("%Y-%m-%d"),
            "topic": topic,
            "search_volume_index": round(min(10, last_vol * (1 + gr) ** i), 3),
            "is_forecast": True,
        })
    return pd.DataFrame(forecasts)


if __name__ == "__main__":
    trend_df = generate_weekly_trend_data()
    rising = identify_rising_topics(trend_df)
    print("=== Rising Topics (Next 4 Weeks) ===")
    print(rising[["topic", "search_volume_index", "growth_rate", "opportunity_score", "status"]].to_string(index=False))
