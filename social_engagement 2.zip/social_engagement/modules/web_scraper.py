"""
Module: Web Scraper
Web scraping capabilities using Selenium and BeautifulSoup
For when API access is unavailable or limited
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup
import time
import yaml
from typing import List, Dict, Optional
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.logger import setup_logger

logger = setup_logger("web_scraper")


class SocialMediaScraper:
    """Base class for social media web scraping"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Initialize scraper with configuration"""
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.scraping_config = self.config.get('scraping', {})
        self.enabled = self.scraping_config.get('enabled', False)
        self.headless = self.scraping_config.get('headless', True)
        self.timeout = self.scraping_config.get('timeout', 30)
        self.max_pages = self.scraping_config.get('max_pages', 10)
        
        self.driver = None
    
    def _init_driver(self):
        """Initialize Selenium WebDriver"""
        if self.driver:
            return
        
        chrome_options = Options()
        if self.headless:
            chrome_options.add_argument('--headless')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument(f'user-agent={self.scraping_config.get("user_agent", "")}')
        
        try:
            self.driver = webdriver.Chrome(options=chrome_options)
            logger.info("WebDriver initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize WebDriver: {e}")
            raise
    
    def _wait_for_element(self, by: By, value: str, timeout: Optional[int] = None):
        """Wait for element to be present"""
        timeout = timeout or self.timeout
        try:
            element = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((by, value))
            )
            return element
        except TimeoutException:
            logger.warning(f"Timeout waiting for element: {value}")
            return None
    
    def close(self):
        """Close the WebDriver"""
        if self.driver:
            self.driver.quit()
            self.driver = None
            logger.info("WebDriver closed")
    
    def __enter__(self):
        self._init_driver()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class InstagramScraper(SocialMediaScraper):
    """Instagram web scraper"""
    
    def scrape_profile(self, username: str) -> Dict:
        """
        Scrape Instagram profile data
        
        Args:
            username: Instagram username
            
        Returns:
            Profile data including follower count, posts, etc.
        """
        if not self.enabled:
            logger.warning("Scraping is disabled in config")
            return {}
        
        self._init_driver()
        url = f"https://www.instagram.com/{username}/"
        
        try:
            logger.info(f"Scraping Instagram profile: {username}")
            self.driver.get(url)
            time.sleep(3)  # Wait for page load
            
            # Parse page source with BeautifulSoup
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Extract profile data (structure may change)
            profile_data = {
                'username': username,
                'url': url,
                'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Try to extract follower count, posts, etc.
            # Note: Instagram's HTML structure changes frequently
            # This is a simplified example
            
            meta_tags = soup.find_all('meta', property='og:description')
            if meta_tags:
                description = meta_tags[0].get('content', '')
                # Parse follower count from description
                profile_data['description'] = description
            
            logger.info(f"Successfully scraped profile: {username}")
            return profile_data
            
        except Exception as e:
            logger.error(f"Error scraping Instagram profile {username}: {e}")
            return {}
    
    def scrape_post_comments(self, post_url: str, max_comments: int = 50) -> List[str]:
        """
        Scrape comments from an Instagram post
        
        Args:
            post_url: URL of the Instagram post
            max_comments: Maximum number of comments to scrape
            
        Returns:
            List of comment texts
        """
        if not self.enabled:
            logger.warning("Scraping is disabled in config")
            return []
        
        self._init_driver()
        
        try:
            logger.info(f"Scraping comments from: {post_url}")
            self.driver.get(post_url)
            time.sleep(3)
            
            comments = []
            
            # Scroll to load more comments
            for _ in range(min(5, max_comments // 10)):
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(2)
            
            # Parse comments
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            # Find comment elements (structure may vary)
            comment_elements = soup.find_all('span', class_='_ap3a')
            
            for elem in comment_elements[:max_comments]:
                comment_text = elem.get_text(strip=True)
                if comment_text:
                    comments.append(comment_text)
            
            logger.info(f"Scraped {len(comments)} comments")
            return comments
            
        except Exception as e:
            logger.error(f"Error scraping comments: {e}")
            return []


class YouTubeScraper(SocialMediaScraper):
    """YouTube web scraper"""
    
    def scrape_video_data(self, video_url: str) -> Dict:
        """
        Scrape YouTube video data
        
        Args:
            video_url: YouTube video URL
            
        Returns:
            Video metadata and statistics
        """
        if not self.enabled:
            logger.warning("Scraping is disabled in config")
            return {}
        
        self._init_driver()
        
        try:
            logger.info(f"Scraping YouTube video: {video_url}")
            self.driver.get(video_url)
            time.sleep(5)  # Wait for page load
            
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            video_data = {
                'url': video_url,
                'scraped_at': time.strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Extract title
            title_elem = soup.find('meta', property='og:title')
            if title_elem:
                video_data['title'] = title_elem.get('content', '')
            
            # Extract view count, likes, etc.
            # Note: YouTube's structure changes frequently
            
            logger.info(f"Successfully scraped video data")
            return video_data
            
        except Exception as e:
            logger.error(f"Error scraping YouTube video: {e}")
            return {}
    
    def scrape_channel_videos(self, channel_url: str, max_videos: int = 20) -> List[Dict]:
        """
        Scrape videos from a YouTube channel
        
        Args:
            channel_url: YouTube channel URL
            max_videos: Maximum number of videos to scrape
            
        Returns:
            List of video data
        """
        if not self.enabled:
            logger.warning("Scraping is disabled in config")
            return []
        
        self._init_driver()
        
        try:
            logger.info(f"Scraping YouTube channel: {channel_url}")
            videos_url = f"{channel_url}/videos"
            self.driver.get(videos_url)
            time.sleep(5)
            
            # Scroll to load more videos
            for _ in range(min(3, max_videos // 10)):
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(2)
            
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            videos = []
            # Extract video links and basic info
            # Structure varies based on YouTube's current layout
            
            logger.info(f"Scraped {len(videos)} videos from channel")
            return videos
            
        except Exception as e:
            logger.error(f"Error scraping YouTube channel: {e}")
            return []


class TrendScraper(SocialMediaScraper):
    """Scraper for trending topics and hashtags"""
    
    def scrape_trending_hashtags(self, platform: str = "instagram") -> List[Dict]:
        """
        Scrape trending hashtags
        
        Args:
            platform: Social media platform (instagram, twitter, tiktok)
            
        Returns:
            List of trending hashtags with metrics
        """
        if not self.enabled:
            logger.warning("Scraping is disabled in config")
            return []
        
        self._init_driver()
        
        try:
            if platform == "instagram":
                url = "https://www.instagram.com/explore/tags/"
            elif platform == "twitter":
                url = "https://twitter.com/explore/tabs/trending"
            else:
                logger.warning(f"Unsupported platform: {platform}")
                return []
            
            logger.info(f"Scraping trending hashtags from {platform}")
            self.driver.get(url)
            time.sleep(5)
            
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            
            trending = []
            # Extract trending hashtags
            # Implementation depends on platform structure
            
            logger.info(f"Found {len(trending)} trending hashtags")
            return trending
            
        except Exception as e:
            logger.error(f"Error scraping trending hashtags: {e}")
            return []


def scrape_google_trends(keywords: List[str]) -> Dict[str, float]:
    """
    Scrape Google Trends data for keywords
    
    Args:
        keywords: List of keywords to check
        
    Returns:
        Dictionary mapping keywords to trend scores
    """
    # Note: Consider using pytrends library for Google Trends
    # This is a placeholder for the scraping logic
    logger.info(f"Checking Google Trends for {len(keywords)} keywords")
    
    trends = {}
    for keyword in keywords:
        # Placeholder: actual implementation would scrape Google Trends
        trends[keyword] = 0.0
    
    return trends


if __name__ == "__main__":
    print("🕷️  Testing Web Scraper...")
    
    # Test scraper initialization
    try:
        with InstagramScraper() as scraper:
            print("✅ Instagram scraper initialized")
        
        with YouTubeScraper() as scraper:
            print("✅ YouTube scraper initialized")
        
        print("\n⚠️  Note: Enable scraping in config/config.yaml and ensure ChromeDriver is installed")
        print("⚠️  Web scraping should be used responsibly and in compliance with platform ToS")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        print("💡 Make sure ChromeDriver is installed: brew install chromedriver (macOS)")

