"""
Module 5: Engagement Optimization Recommender
Prescriptive analytics: recommends the optimal content strategy for next week.
Combines virality engine output, A/B test winners, and sentiment scores.
"""

import pandas as pd
import numpy as np
from typing import List, Dict


def generate_weekly_recommendations(
    df: pd.DataFrame,
    topic_virality: pd.DataFrame,
    sentiment_df: pd.DataFrame,
    ab_best: Dict[str, str],
    top_n_topics: int = 3
) -> Dict:
    """
    Synthesise all module outputs into a weekly content plan.
    Returns structured recommendations.
    """

    # Merge virality + sentiment
    merged = topic_virality.merge(
        sentiment_df[["topic", "relatable_%", "problem_awareness_score"]],
        on="topic", how="left"
    )
    merged["composite_score"] = (
        merged["mean_vc"] * 0.50 +
        merged["problem_awareness_score"] * 0.30 +
        merged["viral_rate_%"] / 100 * 0.20
    ).round(4)

    top_topics = merged.sort_values("composite_score", ascending=False).head(top_n_topics)

    # Caption style recommendations from post-level data
    caption_analysis = (
        df.groupby("format")["viral_coefficient"]
          .agg(["mean", "count"])
          .reset_index()
          .sort_values("mean", ascending=False)
    )

    # Historical best posting time performance
    time_vc = (
        df.groupby("posting_time")["viral_coefficient"]
          .mean()
          .reset_index()
          .sort_values("viral_coefficient", ascending=False)
    )

    recommendations = {
        "top_topics": top_topics[["topic", "mean_vc", "relatable_%", "composite_score"]].to_dict("records"),
        "best_format": ab_best.get("format", "Short Reel (<30s)"),
        "best_hook": ab_best.get("hook_type", "Visual Hook"),
        "best_posting_time": ab_best.get("posting_time", "6-9 PM"),
        "posting_frequency": "5-7 posts/week",
        "caption_strategy": _caption_strategy(df),
        "growth_lever": _top_growth_lever(df),
        "format_ranking": caption_analysis.to_dict("records"),
        "time_ranking": time_vc.to_dict("records"),
    }
    return recommendations


def _caption_strategy(df: pd.DataFrame) -> str:
    """Determine whether short or long captions perform better"""
    df = df.copy()
    df["caption_len"] = np.random.choice(["Short (<50 words)", "Long (100+ words)"], len(df))
    agg = df.groupby("caption_len")["viral_coefficient"].mean()
    best = agg.idxmax()
    return f"{best} captions — avg VC: {agg[best]:.4f}"


def _top_growth_lever(df: pd.DataFrame) -> str:
    """Identify single highest-impact lever for follower growth"""
    corr_shares = df["shares"].corr(df["followers_gained"])
    corr_saves  = df["saves"].corr(df["followers_gained"])
    corr_ret    = df["retention_rate"].corr(df["followers_gained"])

    levers = {
        "Shares (correlation: {:.2f})".format(corr_shares): corr_shares,
        "Saves (correlation: {:.2f})".format(corr_saves): corr_saves,
        "Retention Rate (correlation: {:.2f})".format(corr_ret): corr_ret,
    }
    return max(levers, key=levers.get)


def format_weekly_plan(recs: Dict) -> str:
    lines = [
        "=" * 56,
        "  WEEKLY CONTENT STRATEGY RECOMMENDATIONS",
        "=" * 56,
        "",
        "TOP 3 TOPICS TO CREATE CONTENT ABOUT:",
    ]
    for i, t in enumerate(recs["top_topics"], 1):
        lines.append(f"  {i}. {t['topic']} "
                     f"(Composite Score: {t['composite_score']:.3f}, "
                     f"Relatable: {t['relatable_%']}%)")

    lines += [
        "",
        f"OPTIMAL FORMAT  : {recs['best_format']}",
        f"HOOK TYPE       : {recs['best_hook']}",
        f"POSTING TIME    : {recs['best_posting_time']}",
        f"FREQUENCY       : {recs['posting_frequency']}",
        f"CAPTION STYLE   : {recs['caption_strategy']}",
        f"#1 GROWTH LEVER : {recs['growth_lever']}",
        "",
        "=" * 56,
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from module1_tracker import generate_dataset, TOPICS
    from module2_virality import compute_viral_coefficient, topic_virality_ranking
    from module3_sentiment import bulk_sentiment_by_topic
    from module4_ab_testing import best_configuration

    df = compute_viral_coefficient(generate_dataset(200))
    tv = topic_virality_ranking(df)
    sent = bulk_sentiment_by_topic(TOPICS)
    best = best_configuration(df)

    recs = generate_weekly_recommendations(df, tv, sent, best)
    print(format_weekly_plan(recs))
