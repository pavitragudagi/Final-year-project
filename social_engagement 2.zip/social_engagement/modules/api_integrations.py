"""
Module: API Integrations
Real API integration for Instagram, YouTube, and Twitter
Handles data extraction from social media platforms
"""

import requests
import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import yaml
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.logger import setup_logger

logger = setup_logger("api_integrations")


class SocialMediaAPIClient:
    """Base class for social media API clients"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Initialize API client with configuration"""
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        self.rate_limit_delay = self.config['data_collection']['rate_limit_delay']
        self.max_retries = self.config['data_collection']['max_retries']
        self.timeout = self.config['data_collection']['timeout']
    
    def _handle_rate_limit(self):
        """Handle API rate limiting"""
        time.sleep(self.rate_limit_delay)
    
    def _retry_request(self, func, *args, **kwargs):
        """Retry failed requests"""
        for attempt in range(self.max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed: {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    raise


class InstagramAPIClient(SocialMediaAPIClient):
    """Instagram Graph API client"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        super().__init__(config_path)
        self.api_config = self.config['apis']['instagram']
        self.access_token = self.api_config['access_token']
        self.api_version = self.api_config['api_version']
        self.base_url = f"https://graph.facebook.com/{self.api_version}"
    
    def get_user_media(self, user_id: str, limit: int = 100) -> List[Dict]:
        """
        Fetch user's media posts
        
        Args:
            user_id: Instagram user ID
            limit: Number of posts to fetch
            
        Returns:
            List of media objects with engagement metrics
        """
        logger.info(f"Fetching media for user {user_id}")
        
        url = f"{self.base_url}/{user_id}/media"
        params = {
            'fields': 'id,caption,media_type,media_url,permalink,timestamp,'
                     'like_count,comments_count,insights.metric(impressions,reach,saved,shares)',
            'access_token': self.access_token,
            'limit': limit
        }
        
        try:
            response = self._retry_request(
                requests.get, url, params=params, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            self._handle_rate_limit()
            return data.get('data', [])
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Instagram API error: {e}")
            return []
    
    def get_media_insights(self, media_id: str) -> Dict[str, Any]:
        """
        Get detailed insights for a specific media post
        
        Args:
            media_id: Instagram media ID
            
        Returns:
            Dictionary with engagement metrics
        """
        url = f"{self.base_url}/{media_id}/insights"
        params = {
            'metric': 'impressions,reach,engagement,saved,shares',
            'access_token': self.access_token
        }
        
        try:
            response = self._retry_request(
                requests.get, url, params=params, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            # Parse insights into structured format
            insights = {}
            for item in data.get('data', []):
                insights[item['name']] = item['values'][0]['value']
            
            self._handle_rate_limit()
            return insights
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching insights for {media_id}: {e}")
            return {}
    
    def get_account_insights(self, user_id: str, period: str = "day") -> Dict:
        """
        Get account-level insights
        
        Args:
            user_id: Instagram user ID
            period: Time period (day, week, days_28)
            
        Returns:
            Account metrics
        """
        url = f"{self.base_url}/{user_id}/insights"
        params = {
            'metric': 'impressions,reach,profile_views,follower_count',
            'period': period,
            'access_token': self.access_token
        }
        
        try:
            response = self._retry_request(
                requests.get, url, params=params, timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching account insights: {e}")
            return {}


class YouTubeAPIClient(SocialMediaAPIClient):
    """YouTube Data API v3 client"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        super().__init__(config_path)
        self.api_key = self.config['apis']['youtube']['api_key']
        self.base_url = "https://www.googleapis.com/youtube/v3"
    
    def get_channel_videos(self, channel_id: str, max_results: int = 50) -> List[Dict]:
        """
        Fetch videos from a YouTube channel
        
        Args:
            channel_id: YouTube channel ID
            max_results: Maximum number of videos to fetch
            
        Returns:
            List of video objects
        """
        logger.info(f"Fetching videos for channel {channel_id}")
        
        # First, get the uploads playlist ID
        url = f"{self.base_url}/channels"
        params = {
            'part': 'contentDetails',
            'id': channel_id,
            'key': self.api_key
        }
        
        try:
            response = self._retry_request(
                requests.get, url, params=params, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            if not data.get('items'):
                logger.warning(f"No channel found for ID {channel_id}")
                return []
            
            uploads_playlist_id = data['items'][0]['contentDetails']['relatedPlaylists']['uploads']
            
            # Get videos from uploads playlist
            return self._get_playlist_videos(uploads_playlist_id, max_results)
        
        except requests.exceptions.RequestException as e:
            logger.error(f"YouTube API error: {e}")
            return []
    
    def _get_playlist_videos(self, playlist_id: str, max_results: int) -> List[Dict]:
        """Get videos from a playlist"""
        url = f"{self.base_url}/playlistItems"
        params = {
            'part': 'snippet,contentDetails',
            'playlistId': playlist_id,
            'maxResults': min(max_results, 50),
            'key': self.api_key
        }
        
        videos = []
        
        try:
            response = self._retry_request(
                requests.get, url, params=params, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            for item in data.get('items', []):
                video_id = item['contentDetails']['videoId']
                video_stats = self.get_video_statistics(video_id)
                
                videos.append({
                    'video_id': video_id,
                    'title': item['snippet']['title'],
                    'description': item['snippet']['description'],
                    'published_at': item['snippet']['publishedAt'],
                    **video_stats
                })
            
            self._handle_rate_limit()
            return videos
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching playlist videos: {e}")
            return []
    
    def get_video_statistics(self, video_id: str) -> Dict[str, Any]:
        """
        Get detailed statistics for a video
        
        Args:
            video_id: YouTube video ID
            
        Returns:
            Video statistics
        """
        url = f"{self.base_url}/videos"
        params = {
            'part': 'statistics,contentDetails',
            'id': video_id,
            'key': self.api_key
        }
        
        try:
            response = self._retry_request(
                requests.get, url, params=params, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            if not data.get('items'):
                return {}
            
            stats = data['items'][0]['statistics']
            content = data['items'][0]['contentDetails']
            
            return {
                'views': int(stats.get('viewCount', 0)),
                'likes': int(stats.get('likeCount', 0)),
                'comments': int(stats.get('commentCount', 0)),
                'duration': content.get('duration', ''),
            }
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching video statistics: {e}")
            return {}
    
    def search_videos(self, query: str, max_results: int = 25) -> List[Dict]:
        """
        Search for videos by keyword
        
        Args:
            query: Search query
            max_results: Maximum results to return
            
        Returns:
            List of video search results
        """
        url = f"{self.base_url}/search"
        params = {
            'part': 'snippet',
            'q': query,
            'type': 'video',
            'maxResults': max_results,
            'key': self.api_key
        }
        
        try:
            response = self._retry_request(
                requests.get, url, params=params, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            self._handle_rate_limit()
            return data.get('items', [])
        
        except requests.exceptions.RequestException as e:
            logger.error(f"YouTube search error: {e}")
            return []


class TwitterAPIClient(SocialMediaAPIClient):
    """Twitter API v2 client"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        super().__init__(config_path)
        self.bearer_token = self.config['apis']['twitter']['bearer_token']
        self.base_url = "https://api.twitter.com/2"
    
    def _get_headers(self) -> Dict[str, str]:
        """Get authorization headers"""
        return {"Authorization": f"Bearer {self.bearer_token}"}
    
    def get_user_tweets(self, user_id: str, max_results: int = 100) -> List[Dict]:
        """
        Fetch user's tweets
        
        Args:
            user_id: Twitter user ID
            max_results: Number of tweets to fetch
            
        Returns:
            List of tweets with metrics
        """
        logger.info(f"Fetching tweets for user {user_id}")
        
        url = f"{self.base_url}/users/{user_id}/tweets"
        params = {
            'max_results': min(max_results, 100),
            'tweet.fields': 'created_at,public_metrics,entities',
            'expansions': 'attachments.media_keys'
        }
        
        try:
            response = self._retry_request(
                requests.get, url, headers=self._get_headers(),
                params=params, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            self._handle_rate_limit()
            return data.get('data', [])
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Twitter API error: {e}")
            return []
    
    def search_recent_tweets(self, query: str, max_results: int = 100) -> List[Dict]:
        """
        Search recent tweets
        
        Args:
            query: Search query
            max_results: Maximum results
            
        Returns:
            List of matching tweets
        """
        url = f"{self.base_url}/tweets/search/recent"
        params = {
            'query': query,
            'max_results': min(max_results, 100),
            'tweet.fields': 'created_at,public_metrics'
        }
        
        try:
            response = self._retry_request(
                requests.get, url, headers=self._get_headers(),
                params=params, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            self._handle_rate_limit()
            return data.get('data', [])
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Twitter search error: {e}")
            return []


if __name__ == "__main__":
    # Test API clients (requires valid credentials in config)
    print("🔌 Testing API Integrations...")
    
    try:
        # Test Instagram
        ig_client = InstagramAPIClient()
        print("✅ Instagram API client initialized")
        
        # Test YouTube
        yt_client = YouTubeAPIClient()
        print("✅ YouTube API client initialized")
        
        # Test Twitter
        tw_client = TwitterAPIClient()
        print("✅ Twitter API client initialized")
        
        print("\n⚠️  Note: Add valid API credentials to config/config.yaml to use these clients")
        
    except Exception as e:
        print(f"❌ Error: {e}")

