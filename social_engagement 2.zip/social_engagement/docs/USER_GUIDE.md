# User Guide - Data-Driven Social Engagement Initiative

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Quick Start](#quick-start)
4. [Module Overview](#module-overview)
5. [Dashboard Guide](#dashboard-guide)
6. [API Integration](#api-integration)
7. [Configuration](#configuration)
8. [Data Export](#data-export)
9. [Troubleshooting](#troubleshooting)
10. [Best Practices](#best-practices)

---

## Introduction

The Data-Driven Social Engagement Initiative is a comprehensive analytics platform that measures emotion, quantifies relatability, and optimizes human connection through rigorous statistical analysis. This guide will help you set up, configure, and use all features of the platform.

### Key Features
- **Content Performance Tracking**: Monitor engagement metrics across platforms
- **Virality Prediction**: Calculate viral coefficients and predict content performance
- **Sentiment Analysis**: NLP-powered audience sentiment classification
- **A/B Testing**: Statistical significance testing for content variables
- **Trend Forecasting**: Identify rising topics and predict future trends
- **Automated Recommendations**: Data-backed weekly content strategy

---

## Installation

### Prerequisites
- Python 3.9 or higher
- pip package manager
- 4GB RAM minimum
- Internet connection for API access

### Step 1: Clone or Download the Project
```bash
cd /path/to/your/workspace
# If using git:
git clone <repository-url>
cd social_engagement
```

### Step 2: Create Virtual Environment
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

### Step 3: Install Dependencies
```bash
# Upgrade pip
pip install --upgrade pip

# Install all requirements
pip install -r requirements.txt

# Download NLP corpora
python -m textblob.download_corpora
python -m spacy download en_core_web_sm
```

### Step 4: Configure Environment
```bash
# Copy environment template
cp .env.example .env

# Edit .env with your API credentials (optional for demo)
nano .env  # or use your preferred editor
```

### Step 5: Initialize Database
```bash
# Run database initialization
python config/database.py
```

---

## Quick Start

### Running the Dashboard
```bash
# Make sure virtual environment is activated
streamlit run dashboard.py
```

The dashboard will open in your browser at `http://localhost:8501`

### Using Docker (Alternative)
```bash
# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f

# Stop the application
docker-compose down
```

---

## Module Overview

### Module 1: Content Performance Tracker
**File**: `modules/module1_tracker.py`

Generates structured datasets with engagement metrics.

```python
from modules.module1_tracker import generate_dataset, get_performance_summary

# Generate 250 posts
df = generate_dataset(250)

# Get performance summary
summary = get_performance_summary(df)
print(summary)
```

**Key Functions**:
- `generate_dataset(n_posts)`: Create synthetic content data
- `get_performance_summary(df)`: Calculate aggregate metrics
- `TOPICS`: List of available content topics

### Module 2: Virality Prediction Engine
**File**: `modules/module2_virality.py`

Calculates viral coefficients and ranks topics.

```python
from modules.module2_virality import compute_viral_coefficient, predict_virality

# Calculate viral coefficients
df = compute_viral_coefficient(df)

# Predict for new post
config = {
    'topic': 'Social Anxiety',
    'format': 'Short Reel',
    'hook_type': 'Question Hook',
    'posting_time': '6-9 PM'
}
predicted_vc = predict_virality(df, config)
```

**Viral Coefficient Formula**:
```
VC = (Shares × 0.40) + (Saves × 0.30) + (Comments × 0.15) + 
     (Likes × 0.10) + (Retention × 0.05)
```

**Tiers**:
- 🔥 Viral: VC ≥ 0.75
- ✅ High: VC ≥ 0.50
- 📊 Medium: VC ≥ 0.25
- ⚠️ Low: VC < 0.25

### Module 3: Sentiment Analyzer (NLP)
**File**: `modules/module3_sentiment.py`

Analyzes audience sentiment using NLP.

```python
from modules.module3_sentiment import analyse_comment, bulk_sentiment_by_topic

# Analyze single comment
result = analyse_comment("This really helped me understand my anxiety!")
print(result['label'])  # "Relatable"

# Bulk analysis by topic
sentiment_df = bulk_sentiment_by_topic(['Social Anxiety', 'Dating Struggles'])
```

**Sentiment Labels**:
- **Relatable**: Positive engagement, problem awareness
- **Neutral**: Informational, no strong emotion
- **Not Resonating**: Negative, dismissive, or confused

### Module 4: A/B Testing Framework
**File**: `modules/module4_ab_testing.py`

Statistical significance testing using Welch's t-test.

```python
from modules.module4_ab_testing import run_ab_test, best_configuration

# Run A/B test
results = run_ab_test(df, variable='format', metric='viral_coefficient')

# Get best configuration
best = best_configuration(df)
print(f"Best format: {best['format']}")
print(f"Best hook: {best['hook_type']}")
```

**Test Variables**:
- Format: Short Reel, Long Reel, Carousel, Static Post, Story
- Hook Type: Visual, Text, Question, Story Hook
- Posting Time: 7-9 AM, 12-2 PM, 6-9 PM, 10 PM+

### Module 5: Optimization Recommender
**File**: `modules/module5_recommender.py`

Generates weekly content strategy recommendations.

```python
from modules.module5_recommender import generate_weekly_recommendations

recommendations = generate_weekly_recommendations(df, topic_vc, sentiment, ab_best)
print(recommendations['top_topics'])
print(recommendations['best_format'])
```

**Composite Score Formula**:
```
Score = (Viral Coefficient × 0.50) + (Sentiment × 0.30) + (Viral Rate × 0.20)
```

### Module 7: Trend Forecasting
**File**: `modules/module7_trends.py`

Identifies rising topics and forecasts trends.

```python
from modules.module7_trends import identify_rising_topics, forecast_next_weeks

# Get rising topics
rising = identify_rising_topics(trend_df, top_n=6)

# Forecast next 4 weeks
forecast = forecast_next_weeks(trend_df, 'Social Anxiety', n_weeks=4)
```

---

## Dashboard Guide

### Tab 1: Virality Engine
- **Topic Ranking**: Bar chart showing viral coefficient by topic
- **Save-to-Share Ratio**: Scatter plot with viral tier coloring
- **Tier Distribution**: Pie chart of content performance tiers
- **Full Table**: Complete topic virality metrics

### Tab 2: Sentiment NLP
- **Problem Awareness**: Stacked bar chart of sentiment breakdown
- **Live Comment Analyzer**: Test sentiment analysis on simulated comments
- **Topic Summary**: Table with sentiment percentages

### Tab 3: A/B Testing
- **Test Results**: Statistical significance for content variables
- **Format × Time Heatmap**: Performance matrix
- **Optimal Configuration**: Best performing settings

### Tab 4: Recommendations
- **Top Topics**: Ranked by composite score
- **Optimal Settings**: Best format, hook, time, frequency
- **Format Performance**: Bar chart ranking
- **Virality Predictor**: Predict VC for new post configurations

### Tab 5: Trend Forecast
- **Rising Topics**: Opportunity score ranking
- **Historical Trends**: 12-week search volume index
- **4-Week Forecast**: Predictive trend analysis

### Tab 6: Strategy Report
- **Scatter Analysis**: VC vs selected metric
- **Follower Growth**: Time series with cumulative line
- **Correlation Matrix**: Heatmap of metric relationships
- **Dataset Download**: Export filtered data as CSV

### Sidebar Filters
- **Platform**: Filter by social media platform
- **Topics**: Select specific topics to analyze
- **Date Range**: Set time period for analysis
- **Primary KPI**: Choose main metric to display

---

## API Integration

### Instagram Graph API

1. **Get Access Token**:
   - Go to [Facebook Developers](https://developers.facebook.com/)
   - Create an app and get Instagram Graph API access
   - Generate access token

2. **Configure**:
```yaml
# config/config.yaml
apis:
  instagram:
    access_token: "YOUR_TOKEN"
    app_id: "YOUR_APP_ID"
    app_secret: "YOUR_SECRET"
```

3. **Usage**:
```python
from modules.api_integrations import InstagramAPIClient

client = InstagramAPIClient()
media = client.get_user_media(user_id="123456789", limit=50)
insights = client.get_media_insights(media_id="987654321")
```

### YouTube Data API

1. **Get API Key**:
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Enable YouTube Data API v3
   - Create API key

2. **Configure**:
```yaml
# config/config.yaml
apis:
  youtube:
    api_key: "YOUR_API_KEY"
```

3. **Usage**:
```python
from modules.api_integrations import YouTubeAPIClient

client = YouTubeAPIClient()
videos = client.get_channel_videos(channel_id="UC...", max_results=50)
stats = client.get_video_statistics(video_id="dQw4w9WgXcQ")
```

### Twitter API v2

1. **Get Bearer Token**:
   - Go to [Twitter Developer Portal](https://developer.twitter.com/)
   - Create app and get API credentials

2. **Configure**:
```yaml
# config/config.yaml
apis:
  twitter:
    bearer_token: "YOUR_BEARER_TOKEN"
```

3. **Usage**:
```python
from modules.api_integrations import TwitterAPIClient

client = TwitterAPIClient()
tweets = client.get_user_tweets(user_id="123456789")
search_results = client.search_recent_tweets(query="social anxiety")
```

---

## Configuration

### config/config.yaml

```yaml
# Database
database:
  type: "sqlite"
  path: "data/social_engagement.db"

# API Credentials
apis:
  instagram:
    access_token: "YOUR_TOKEN"
  youtube:
    api_key: "YOUR_KEY"
  twitter:
    bearer_token: "YOUR_TOKEN"

# Model Settings
models:
  virality:
    weights:
      shares: 0.40
      saves: 0.30
      comments: 0.15
      likes: 0.10
      retention: 0.05

# Analytics
analytics:
  default_lookback_days: 90
  forecast_weeks: 4
  significance_level: 0.05

# Logging
logging:
  level: "INFO"
  file: "logs/app.log"
```

### Environment Variables (.env)

```bash
# API Credentials
INSTAGRAM_ACCESS_TOKEN=your_token
YOUTUBE_API_KEY=your_key
TWITTER_BEARER_TOKEN=your_token

# Application Settings
LOG_LEVEL=INFO
STREAMLIT_PORT=8501

# Scraping (optional)
SCRAPING_ENABLED=false
SCRAPING_HEADLESS=true
```

---

## Data Export

### Using Export Manager

```python
from modules.export_manager import ExportManager, ReportGenerator

export_mgr = ExportManager(output_dir="data/exports")

# Export to CSV
csv_path = export_mgr.export_to_csv(df, "content_performance")

# Export to Excel
excel_path = export_mgr.export_to_excel(df, "analytics_report")

# Export to JSON
json_path = export_mgr.export_to_json(df, "data_export")

# Multi-sheet Excel
data_dict = {
    'Performance': df,
    'Sentiment': sentiment_df,
    'Trends': trend_df
}
multi_path = export_mgr.export_multi_sheet_excel(data_dict, "full_report")
```

### Generate Reports

```python
report_gen = ReportGenerator()

# Weekly strategy report
report_path = report_gen.generate_weekly_report(
    recommendations, topic_virality, sentiment_data
)

# Performance summary
summary_path = report_gen.generate_performance_summary(df)
```

---

## Troubleshooting

### Common Issues

#### 1. ModuleNotFoundError
```bash
# Solution: Reinstall dependencies
pip install -r requirements.txt
```

#### 2. TextBlob Corpora Missing
```bash
# Solution: Download corpora
python -m textblob.download_corpora
```

#### 3. Streamlit Port Already in Use
```bash
# Solution: Use different port
streamlit run dashboard.py --server.port=8502
```

#### 4. Database Locked Error
```bash
# Solution: Close other connections
rm data/social_engagement.db
python config/database.py
```

#### 5. API Rate Limit Exceeded
```yaml
# Solution: Increase delay in config.yaml
data_collection:
  rate_limit_delay: 5  # Increase from 2 to 5 seconds
```

#### 6. ChromeDriver Not Found (for scraping)
```bash
# macOS
brew install chromedriver

# Ubuntu/Debian
sudo apt-get install chromium-chromedriver

# Windows
# Download from: https://chromedriver.chromium.org/
```

### Debug Mode

Enable detailed logging:
```yaml
# config/config.yaml
logging:
  level: "DEBUG"
```

View logs:
```bash
tail -f logs/app.log
```

---

## Best Practices

### 1. Data Collection
- Start with synthetic data to test the system
- Gradually integrate real API data
- Respect API rate limits
- Cache frequently accessed data

### 2. Model Training
- Retrain models monthly with new data
- Version your models using ModelManager
- Track model performance metrics
- A/B test model predictions vs actual results

### 3. Dashboard Usage
- Use filters to focus on specific segments
- Export data regularly for backup
- Monitor trends weekly
- Act on recommendations within 48 hours

### 4. Content Strategy
- Focus on top 3 recommended topics
- Test optimal posting times for 2 weeks
- Iterate based on A/B test results
- Track sentiment changes over time

### 5. Performance Optimization
- Clear Streamlit cache periodically
- Limit dataset size for faster loading
- Use database queries instead of loading full datasets
- Schedule heavy computations during off-peak hours

### 6. Security
- Never commit .env file to version control
- Rotate API credentials regularly
- Use environment variables for sensitive data
- Restrict database access permissions

### 7. Collaboration
- Document custom modifications
- Use version control (git)
- Share reports via export manager
- Maintain changelog for updates

---

## Advanced Usage

### Custom Metrics

Add custom viral coefficient weights:
```python
from modules.module2_virality import compute_viral_coefficient

# Custom weights
custom_weights = {
    'shares': 0.50,
    'saves': 0.25,
    'comments': 0.15,
    'likes': 0.05,
    'retention': 0.05
}

df = compute_viral_coefficient(df, weights=custom_weights)
```

### Batch Processing

Process multiple datasets:
```python
from pathlib import Path
import pandas as pd

data_dir = Path("data/raw")
for csv_file in data_dir.glob("*.csv"):
    df = pd.read_csv(csv_file)
    # Process each file
    df = compute_viral_coefficient(df)
    df.to_csv(f"data/processed/{csv_file.name}")
```

### Scheduled Reports

Use cron (Linux/macOS) or Task Scheduler (Windows):
```bash
# crontab -e
# Run weekly report every Monday at 9 AM
0 9 * * 1 cd /path/to/social_engagement && /path/to/venv/bin/python scripts/generate_weekly_report.py
```

---

## Support & Resources

### Documentation
- README.md: Project overview
- This guide: Comprehensive usage instructions
- Code comments: Inline documentation

### Getting Help
1. Check this guide first
2. Review error logs in `logs/app.log`
3. Search for similar issues in project repository
4. Contact project maintainers

### Contributing
- Follow PEP 8 style guidelines
- Add tests for new features
- Update documentation
- Submit pull requests with clear descriptions

---

## Appendix

### A. Glossary

- **Viral Coefficient (VC)**: Weighted score measuring content virality potential
- **Composite Score**: Combined metric for topic recommendation
- **Welch's t-test**: Statistical test for comparing two groups with unequal variance
- **NLP**: Natural Language Processing
- **Sentiment Analysis**: Classification of text emotional tone
- **A/B Testing**: Comparing two variants to determine which performs better

### B. File Structure

```
social_engagement/
├── dashboard.py              # Main Streamlit application
├── requirements.txt          # Python dependencies
├── Dockerfile               # Docker container configuration
├── docker-compose.yml       # Docker Compose setup
├── .env.example            # Environment variables template
├── .gitignore              # Git ignore rules
├── config/
│   ├── config.yaml         # Application configuration
│   ├── database.py         # Database manager
│   └── logger.py           # Logging configuration
├── modules/
│   ├── module1_tracker.py      # Content performance tracking
│   ├── module2_virality.py     # Virality prediction
│   ├── module3_sentiment.py    # Sentiment analysis
│   ├── module4_ab_testing.py   # A/B testing framework
│   ├── module5_recommender.py  # Recommendations engine
│   ├── module7_trends.py       # Trend forecasting
│   ├── api_integrations.py     # Social media APIs
│   ├── web_scraper.py          # Web scraping utilities
│   ├── model_manager.py        # ML model persistence
│   └── export_manager.py       # Data export utilities
├── data/                   # Data storage
├── models/                 # Saved ML models
├── logs/                   # Application logs
├── docs/                   # Documentation
└── tests/                  # Unit tests
```

### C. Metrics Reference

| Metric | Description | Range | Interpretation |
|--------|-------------|-------|----------------|
| Viral Coefficient | Weighted virality score | 0.0 - 1.0 | Higher = more viral |
| Retention Rate | % of video watched | 0% - 100% | Higher = more engaging |
| Engagement Rate | (Likes+Comments+Shares)/Reach | 0% - 100% | Higher = better engagement |
| Sentiment Score | Polarity of comments | -1.0 to 1.0 | Positive = relatable |
| Growth Rate | Week-over-week change | -100% to ∞ | Positive = trending up |
| P-value | Statistical significance | 0.0 - 1.0 | <0.05 = significant |

---

**Version**: 1.0.0  
**Last Updated**: December 2024  
**Project**: Data-Driven Social Engagement Initiative  
**Organization**: UNILOX Academy

---

*Built with Python • Pandas • Scikit-learn • NLTK • Streamlit • Plotly*