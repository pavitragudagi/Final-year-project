"""
Module 6: Growth Visualization Dashboard
Interactive Streamlit app integrating all 7 modules.
Run with: streamlit run dashboard.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "modules"))

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from module1_tracker import generate_dataset, get_performance_summary, TOPICS
from module2_virality import compute_viral_coefficient, topic_virality_ranking
from module3_sentiment import bulk_sentiment_by_topic, analyse_post_comments, sentiment_summary
from module4_ab_testing import run_ab_test, best_configuration, segment_performance
from module5_recommender import generate_weekly_recommendations, format_weekly_plan
from module7_trends import generate_weekly_trend_data, identify_rising_topics, forecast_next_weeks

# ─── Page Config ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Social Engagement Analytics",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
  .metric-card {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border: 1px solid #0f3460;
    border-radius: 12px;
    padding: 16px 20px;
    margin-bottom: 12px;
  }
  .metric-label { font-size: 12px; color: #8892b0; text-transform: uppercase; letter-spacing: 1px; }
  .metric-value { font-size: 28px; font-weight: 700; color: #e6f1ff; margin-top: 4px; }
  .metric-delta { font-size: 13px; margin-top: 2px; }
  .section-header {
    font-size: 18px;
    font-weight: 600;
    color: #ccd6f6;
    border-left: 3px solid #64ffda;
    padding-left: 12px;
    margin: 24px 0 16px;
  }
  .highlight-box {
    background: #0d2137;
    border: 1px solid #64ffda33;
    border-radius: 8px;
    padding: 14px 18px;
    margin: 8px 0;
  }
</style>
""", unsafe_allow_html=True)

# ─── Load & Process Data (cached) ────────────────────────────────────────────
@st.cache_data
def load_all_data():
    df = generate_dataset(250)
    df = compute_viral_coefficient(df)
    topic_vc  = topic_virality_ranking(df)
    sentiment = bulk_sentiment_by_topic(TOPICS, n_per_topic=40)
    ab_best   = best_configuration(df)
    trend_df  = generate_weekly_trend_data(weeks=12)
    recs      = generate_weekly_recommendations(df, topic_vc, sentiment, ab_best)
    perf      = get_performance_summary(df)
    return df, topic_vc, sentiment, ab_best, trend_df, recs, perf

df, topic_vc, sentiment, ab_best, trend_df, recs, perf = load_all_data()

# ─── Sidebar ─────────────────────────────────────────────────────────────────
st.sidebar.markdown("""
<img src="https://media.licdn.com/dms/image/v2/D5616AQHGO7M5m5RXVw/profile-displaybackgroundimage-shrink_200_800/B56ZgDm1NAHQAU-/0/1752407168314?e=2147483647&v=beta&t=KvpdLzy19sUL1QQFCTBxkXYz5SDGt33j8Mb-M8zPBrw"
  style="width:100%;border-radius:10px;margin-bottom:8px;">
""", unsafe_allow_html=True)
st.sidebar.markdown("### Filters")
sel_platform = st.sidebar.multiselect("Platform", df["platform"].unique(), default=list(df["platform"].unique()))
sel_topics   = st.sidebar.multiselect("Topics", TOPICS, default=TOPICS[:6])
date_range   = st.sidebar.date_input("Date Range", [pd.to_datetime(df["date"].min()),
                                                     pd.to_datetime(df["date"].max())])
sel_metric   = st.sidebar.selectbox("Primary KPI", ["viral_coefficient", "shares", "saves", "retention_rate", "followers_gained"])

# Filter data
df["date"] = pd.to_datetime(df["date"])

start_date = pd.to_datetime(date_range[0]) if len(date_range) >= 1 else df["date"].min()
end_date   = pd.to_datetime(date_range[1]) if len(date_range) == 2 else df["date"].max()

filtered = df[
    df["platform"].isin(sel_platform) &
    df["topic"].isin(sel_topics if sel_topics else TOPICS) &
    (df["date"] >= start_date) &
    (df["date"] <= end_date)
].copy()

# ─── Header ──────────────────────────────────────────────────────────────────
st.title("📊 Data-Driven Social Engagement Initiative")
# st.markdown("*Replacing creative guesswork with evidence-based analytics. All 7 modules active.*")
st.markdown("---")

# ─── KPI Row ─────────────────────────────────────────────────────────────────
METRIC_LABELS = {
    "viral_coefficient": "Viral Coefficient",
    "shares": "Shares",
    "saves": "Saves",
    "retention_rate": "Retention Rate",
    "followers_gained": "Followers Gained",
}

def fmt_metric(val, col):
    if col == "retention_rate":
        return f"{val:.1%}"
    elif col == "viral_coefficient":
        return f"{val:.3f}"
    else:
        return f"{val:,.0f}"

kpi_val = filtered[sel_metric].sum() if sel_metric == "followers_gained" else filtered[sel_metric].mean()
kpi_label = f"Total {METRIC_LABELS[sel_metric]}" if sel_metric == "followers_gained" else f"Avg {METRIC_LABELS[sel_metric]}"

c1, c2, c3, c4, c5 = st.columns(5)
with c1:
    st.metric("Total Posts", len(filtered), f"+{len(filtered)//10} this week")
with c2:
    st.metric(f"⭐ {kpi_label}", fmt_metric(kpi_val, sel_metric))
with c3:
    st.metric("Avg Retention", f"{filtered['retention_rate'].mean():.1%}")
with c4:
    st.metric("Total Followers Gained", f"{filtered['followers_gained'].sum():,}")
with c5:
    viral_count = (filtered["viral_tier"] == "Viral").sum()
    st.metric("Viral Posts", viral_count, f"{viral_count/len(filtered)*100:.1f}% rate")

st.markdown("---")

# ─── TABS ─────────────────────────────────────────────────────────────────────
tabs = st.tabs([
    "📈 Virality Engine",
    "💬 Sentiment NLP",
    "🧪 A/B Testing",
    "🎯 Recommendations",
    "📡 Trend Forecast",
    "📋 Strategy Report",
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1: VIRALITY ENGINE
# ══════════════════════════════════════════════════════════════════════════════
with tabs[0]:
    st.markdown('<div class="section-header">Viral Coefficient by Topic</div>', unsafe_allow_html=True)
    st.caption("Weighted formula: Shares×0.40 + Saves×0.30 + Comments×0.15 + Likes×0.10 + Retention×0.05")

    col1, col2 = st.columns([3, 2])
    with col1:
        # Use sel_metric to drive the topic ranking bar chart
        topic_metric_agg = filtered.groupby("topic")[sel_metric].mean().reset_index().sort_values(sel_metric)
        metric_label = METRIC_LABELS[sel_metric]
        fig = px.bar(
            topic_metric_agg,
            x=sel_metric, y="topic", orientation="h",
            color=sel_metric, color_continuous_scale="teal",
            labels={sel_metric: f"Avg {metric_label}", "topic": ""},
            title=f"Topic Ranking by {metric_label}",
        )
        fig.update_layout(showlegend=False, height=420, paper_bgcolor="rgba(0,0,0,0)",
                          plot_bgcolor="rgba(0,0,0,0)", font_color="#ccd6f6")
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        scatter_size = sel_metric if sel_metric not in ["viral_tier"] else "viral_coefficient"
        fig2 = px.scatter(
            filtered, x="shares", y="saves",
            color="viral_tier", size=scatter_size,
            hover_data=["topic", "format", "viral_coefficient", sel_metric],
            color_discrete_map={"Low": "#8892b0", "Medium": "#ffd700", "High": "#64ffda", "Viral": "#ff6b6b"},
            title=f"Save-to-Share Ratio (bubble = {METRIC_LABELS[sel_metric]})",
        )
        fig2.update_layout(height=420, paper_bgcolor="rgba(0,0,0,0)",
                           plot_bgcolor="rgba(0,0,0,0)", font_color="#ccd6f6")
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown('<div class="section-header">Viral Tier Distribution</div>', unsafe_allow_html=True)
    tier_counts = filtered["viral_tier"].value_counts().reset_index()
    tier_counts.columns = ["tier", "count"]
    fig3 = px.pie(tier_counts, values="count", names="tier",
                  color="tier",
                  color_discrete_map={"Low": "#8892b0", "Medium": "#ffd700", "High": "#64ffda", "Viral": "#ff6b6b"},
                  hole=0.45, title="Content Tier Breakdown")
    fig3.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="#ccd6f6")
    st.plotly_chart(fig3, use_container_width=True)

    st.markdown('<div class="section-header">Full Topic Virality Table</div>', unsafe_allow_html=True)
    st.dataframe(topic_vc.style.background_gradient(subset=["mean_vc","viral_rate_%"], cmap="YlGn"),
                 use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2: SENTIMENT NLP
# ══════════════════════════════════════════════════════════════════════════════
with tabs[1]:
    st.markdown('<div class="section-header">Problem Awareness by Topic</div>', unsafe_allow_html=True)
    st.caption("NLP pipeline: keyword trigger scoring + TextBlob polarity → Relatable / Neutral / Not Resonating")

    fig = go.Figure()
    for col, color in [("relatable_%", "#64ffda"), ("neutral_%", "#ffd700"), ("not_resonating_%", "#ff6b6b")]:
        fig.add_trace(go.Bar(
            name=col.replace("_%","").replace("_"," ").title(),
            x=sentiment["topic"],
            y=sentiment[col],
            marker_color=color,
        ))
    fig.update_layout(barmode="stack", height=420, title="Comment Sentiment Breakdown by Topic",
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font_color="#ccd6f6", legend=dict(bgcolor="rgba(0,0,0,0)"))
    st.plotly_chart(fig, use_container_width=True)

    # Live comment analyser
    st.markdown('<div class="section-header">Live Comment Analyser</div>', unsafe_allow_html=True)
    live_topic = st.selectbox("Select topic to analyse comments", TOPICS, index=0)
    n_comments = st.slider("Number of simulated comments", 10, 50, 20)
    if st.button("Analyse Comments"):
        comment_df = analyse_post_comments(live_topic, n_comments)
        summ = sentiment_summary(comment_df)

        c1, c2, c3 = st.columns(3)
        with c1: st.metric("Relatable", f"{summ.get('Relatable',0):.1f}%")
        with c2: st.metric("Neutral",   f"{summ.get('Neutral',0):.1f}%")
        with c3: st.metric("Not Resonating", f"{summ.get('Not Resonating',0):.1f}%")

        fig_pie = px.pie(
            pd.DataFrame(summ.items(), columns=["Label","Pct"]),
            values="Pct", names="Label",
            color_discrete_map={"Relatable":"#64ffda","Neutral":"#ffd700","Not Resonating":"#ff6b6b"},
            hole=0.4
        )
        fig_pie.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="#ccd6f6")
        st.plotly_chart(fig_pie, use_container_width=True)

        st.dataframe(
            comment_df[["comment","label","trigger_score","polarity","compound_score"]]
                .style.applymap(
                    lambda v: "background-color: #0d3d2e" if v == "Relatable"
                    else "background-color: #3d1b0d" if v == "Not Resonating" else "",
                    subset=["label"]
                ),
            use_container_width=True
        )

    st.markdown('<div class="section-header">Topic Sentiment Summary Table</div>', unsafe_allow_html=True)
    st.dataframe(sentiment.style.background_gradient(subset=["relatable_%"], cmap="Greens"),
                 use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3: A/B TESTING
# ══════════════════════════════════════════════════════════════════════════════
with tabs[2]:
    st.markdown('<div class="section-header">A/B Test Results</div>', unsafe_allow_html=True)

    ab_var = st.selectbox("Select variable to test", ["format", "hook_type", "posting_time"])
    ab_metric = st.selectbox("Metric", ["viral_coefficient", "shares", "saves", "retention_rate"])

    ab_result = run_ab_test(filtered, ab_var, metric=ab_metric)

    col1, col2 = st.columns([2, 1])
    with col1:
        # Mean VC by group
        grp_means = filtered.groupby(ab_var)[ab_metric].mean().reset_index().sort_values(ab_metric, ascending=False)
        fig = px.bar(grp_means, x=ab_var, y=ab_metric,
                     color=ab_metric, color_continuous_scale="teal",
                     title=f"Mean {ab_metric.replace('_',' ').title()} by {ab_var.replace('_',' ').title()}")
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          font_color="#ccd6f6", showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.markdown("**Statistical Test Results (Welch t-test)**")
        display_cols = ["group_A","group_B","mean_A","mean_B","p_value","significant","winner"]
        sig_df = ab_result[display_cols].copy()
        sig_df["significant"] = sig_df["significant"].map({True: "✅ Yes", False: "❌ No"})
        st.dataframe(sig_df, use_container_width=True, height=350)

    # Heatmap: format × posting_time
    st.markdown('<div class="section-header">Format × Posting Time Heatmap</div>', unsafe_allow_html=True)
    pivot = segment_performance(filtered)
    fig_heat = px.imshow(
        pivot, text_auto=".3f", color_continuous_scale="teal",
        title="Mean Viral Coefficient: Format × Posting Time",
        aspect="auto"
    )
    fig_heat.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="#ccd6f6")
    st.plotly_chart(fig_heat, use_container_width=True)

    # Best config banner
    st.markdown('<div class="section-header">Optimal Configuration</div>', unsafe_allow_html=True)
    best = best_configuration(filtered)
    b1, b2, b3 = st.columns(3)
    with b1: st.success(f"**Best Format:** {best.get('format', '—')}")
    with b2: st.success(f"**Best Hook:** {best.get('hook_type', '—')}")
    with b3: st.success(f"**Best Time:** {best.get('posting_time', '—')}")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4: RECOMMENDATIONS
# ══════════════════════════════════════════════════════════════════════════════
with tabs[3]:
    st.markdown('<div class="section-header">Weekly Content Strategy Recommendations</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**Top Recommended Topics**")
        for i, t in enumerate(recs["top_topics"], 1):
            st.markdown(
                f'<div class="highlight-box"><b>{i}. {t["topic"]}</b><br>'
                f'Composite Score: <b>{t["composite_score"]:.3f}</b> | '
                f'Relatable: <b>{t["relatable_%"]:.0f}%</b></div>',
                unsafe_allow_html=True
            )

    with col2:
        st.markdown("**Optimal Execution Settings**")
        settings = {
            "Format": recs["best_format"],
            "Hook Type": recs["best_hook"],
            "Posting Time": recs["best_posting_time"],
            "Frequency": recs["posting_frequency"],
            "#1 Growth Lever": recs["growth_lever"],
        }
        for k, v in settings.items():
            st.markdown(f'<div class="highlight-box"><small>{k}</small><br><b>{v}</b></div>',
                        unsafe_allow_html=True)

    st.markdown('<div class="section-header">Format Performance Ranking</div>', unsafe_allow_html=True)
    fmt_df = pd.DataFrame(recs["format_ranking"]).rename(columns={"mean":"Avg VC","count":"Posts"})
    fig_fmt = px.bar(fmt_df.sort_values("Avg VC", ascending=False),
                     x="format", y="Avg VC", color="Avg VC",
                     color_continuous_scale="teal",
                     title="Content Format Performance")
    fig_fmt.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          font_color="#ccd6f6", showlegend=False)
    st.plotly_chart(fig_fmt, use_container_width=True)

    st.markdown('<div class="section-header">Posting Time Performance</div>', unsafe_allow_html=True)
    time_df = pd.DataFrame(recs["time_ranking"])
    fig_time = px.bar(time_df.sort_values("viral_coefficient", ascending=False),
                      x="posting_time", y="viral_coefficient",
                      color="viral_coefficient", color_continuous_scale="teal",
                      title="Posting Time vs Viral Coefficient")
    fig_time.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                           font_color="#ccd6f6", showlegend=False)
    st.plotly_chart(fig_time, use_container_width=True)

    # Virality predictor
    st.markdown('<div class="section-header">Virality Predictor (New Post)</div>', unsafe_allow_html=True)
    st.caption("Predict the Viral Coefficient for a new post configuration before you publish.")

    pc1, pc2, pc3, pc4 = st.columns(4)
    with pc1: p_topic = st.selectbox("Topic", TOPICS)
    with pc2: p_format = st.selectbox("Format", df["format"].unique())
    with pc3: p_hook = st.selectbox("Hook", df["hook_type"].unique())
    with pc4: p_time = st.selectbox("Posting Time", df["posting_time"].unique())

    if st.button("Predict Viral Coefficient"):
        from module2_virality import predict_virality
        pred_vc = predict_virality(filtered, {"topic": p_topic, "format": p_format,
                                              "hook_type": p_hook, "posting_time": p_time})
        tier = ("Viral 🔥" if pred_vc > 0.75 else "High ✅" if pred_vc > 0.50
                else "Medium 📊" if pred_vc > 0.25 else "Low ⚠️")
        st.metric("Predicted Viral Coefficient", f"{pred_vc:.4f}", tier)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5: TREND FORECAST
# ══════════════════════════════════════════════════════════════════════════════
with tabs[4]:
    st.markdown('<div class="section-header">Rising Topic Signals</div>', unsafe_allow_html=True)
    rising = identify_rising_topics(trend_df, top_n=6)

    col1, col2 = st.columns([2, 1])
    with col1:
        fig = px.bar(rising.sort_values("opportunity_score"),
                     x="opportunity_score", y="topic", orientation="h",
                     color="growth_rate", color_continuous_scale="teal",
                     title="Topics About to Go Mainstream (Opportunity Score)")
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          font_color="#ccd6f6", showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.markdown("**Status breakdown**")
        for _, row in rising.iterrows():
            st.markdown(
                f'<div class="highlight-box"><b>{row["topic"]}</b><br>'
                f'{row["status"]}<br>'
                f'Volume: {row["search_volume_index"]:.1f}/10 | Growth: +{row["growth_rate"]*100:.0f}%/wk</div>',
                unsafe_allow_html=True
            )

    # Historical trend lines
    st.markdown('<div class="section-header">12-Week Historical Trend</div>', unsafe_allow_html=True)
    trend_topics = st.multiselect("Topics to compare", TOPICS, default=TOPICS[:4])
    filt_trend = trend_df[trend_df["topic"].isin(trend_topics)]
    fig_trend = px.line(filt_trend, x="date", y="search_volume_index", color="topic",
                        title="Search Volume Index over Time", markers=True)
    fig_trend.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                            font_color="#ccd6f6")
    st.plotly_chart(fig_trend, use_container_width=True)

    # Forecast
    st.markdown('<div class="section-header">4-Week Forecast</div>', unsafe_allow_html=True)
    fc_topic = st.selectbox("Forecast topic", TOPICS, index=6)
    hist = trend_df[trend_df["topic"] == fc_topic][["week","date","topic","search_volume_index"]].copy()
    hist["is_forecast"] = False
    fc = forecast_next_weeks(trend_df, fc_topic, n_weeks=4)
    fc_combined = pd.concat([hist, fc])

    fig_fc = px.line(fc_combined, x="date", y="search_volume_index",
                     color="is_forecast", symbol="is_forecast",
                     color_discrete_map={False: "#64ffda", True: "#ff6b6b"},
                     title=f"Forecast: {fc_topic} — Next 4 Weeks")
    fig_fc.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                         font_color="#ccd6f6")
    st.plotly_chart(fig_fc, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 6: STRATEGY REPORT
# ══════════════════════════════════════════════════════════════════════════════
with tabs[5]:
    st.markdown('<div class="section-header">Data-Backed Strategy Report</div>', unsafe_allow_html=True)

    # Scatter: struggle topic vs followers gained
    fig_scatter = px.scatter(
        filtered, x="viral_coefficient", y=sel_metric,
        color="topic", size="saves",
        hover_data=["format", "hook_type", "posting_time"],
        title=f"Viral Coefficient vs {METRIC_LABELS[sel_metric]} (size = Saves)",
        labels={sel_metric: METRIC_LABELS[sel_metric]},
    )
    fig_scatter.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                              font_color="#ccd6f6")
    st.plotly_chart(fig_scatter, use_container_width=True)

    # Time series of followers gained
    st.markdown('<div class="section-header">Follower Growth Over Time</div>', unsafe_allow_html=True)
    ts = filtered.groupby("date")["followers_gained"].sum().reset_index()
    ts["cumulative"] = ts["followers_gained"].cumsum()
    fig_ts = make_subplots(specs=[[{"secondary_y": True}]])
    fig_ts.add_trace(go.Bar(x=ts["date"], y=ts["followers_gained"], name="Daily",
                            marker_color="#0f3460"), secondary_y=False)
    fig_ts.add_trace(go.Scatter(x=ts["date"], y=ts["cumulative"], name="Cumulative",
                                line=dict(color="#64ffda", width=2)), secondary_y=True)
    fig_ts.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                         font_color="#ccd6f6", height=400)
    st.plotly_chart(fig_ts, use_container_width=True)

    # Correlation heatmap
    st.markdown('<div class="section-header">Metric Correlation Matrix</div>', unsafe_allow_html=True)
    num_cols = ["likes","comments","shares","saves","retention_rate","viral_coefficient","followers_gained"]
    corr = filtered[num_cols].corr().round(3)
    fig_corr = px.imshow(corr, text_auto=True, color_continuous_scale="RdBu_r",
                         title="Engagement Metric Correlations", aspect="auto")
    fig_corr.update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="#ccd6f6")
    st.plotly_chart(fig_corr, use_container_width=True)

    # Download the dataset
    st.markdown('<div class="section-header">Download Structured Dataset</div>', unsafe_allow_html=True)
    csv = filtered.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download Dataset (CSV)", csv, "content_performance.csv", "text/csv")

    # Print strategy report
    st.markdown('<div class="section-header">Full Strategy Report</div>', unsafe_allow_html=True)
    st.code(format_weekly_plan(recs), language="")

    st.markdown("---")
    st.caption("Built for the Data-Driven Social Engagement Initiative • Powered by Python · Pandas · Scikit-learn · NLTK · Streamlit · Plotly")